"""Small always-on-top banner on the host while someone is connected,
with a button to kick all viewers. Runs Tk in its own thread."""
import queue
import threading


class Indicator:
    def __init__(self, on_disconnect):
        self.on_disconnect = on_disconnect
        self.q = queue.Queue()
        self.ok = True
        threading.Thread(target=self._run, name="indicator", daemon=True).start()

    def update(self, viewers):
        """viewers: list of IP strings currently connected."""
        self.q.put(list(viewers))

    def _run(self):
        try:
            import tkinter as tk
        except Exception:
            self.ok = False
            return
        root = tk.Tk()
        root.withdraw()
        root.overrideredirect(True)
        root.attributes("-topmost", True)
        root.attributes("-alpha", 0.92)
        root.configure(bg="#c62828")
        frame = tk.Frame(root, bg="#c62828", padx=10, pady=4)
        frame.pack()
        label = tk.Label(frame, text="", fg="white", bg="#c62828", font=("Segoe UI", 10, "bold"))
        label.pack(side="left")
        btn = tk.Button(frame, text="Disconnect", command=self.on_disconnect, relief="flat",
                        bg="#8e0000", fg="white", activebackground="#5f0000", activeforeground="white",
                        font=("Segoe UI", 9), padx=8, bd=0, cursor="hand2")
        btn.pack(side="left", padx=(10, 0))

        def poll():
            viewers = None
            try:
                while True:
                    viewers = self.q.get_nowait()
            except queue.Empty:
                pass
            if viewers is not None:
                if viewers:
                    label.config(text="●  Remote session active: " + ", ".join(sorted(set(viewers))))
                    root.deiconify()
                    root.update_idletasks()
                    w = root.winfo_reqwidth()
                    x = (root.winfo_screenwidth() - w) // 2
                    root.geometry(f"+{x}+0")
                    root.lift()
                else:
                    root.withdraw()
            root.after(200, poll)

        root.after(200, poll)
        root.mainloop()
