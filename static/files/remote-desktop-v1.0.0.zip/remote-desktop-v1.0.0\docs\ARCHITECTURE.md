# Architecture

```
 Viewer (browser)                                   Host (Windows, Python)
 ┌──────────────────────────┐   HTTPS + WSS   ┌───────────────────────────────────────┐
 │ static/index.html        │ ◄─────────────► │ host.py   aiohttp server              │
 │ static/app.js            │                 │   guard middleware (IP allow-list,    │
 │  - draws JPEG tiles on   │  binary frames  │   security headers)                   │
 │    a <canvas>            │ ◄────────────── │   /login /logout /upload /ws          │
 │  - sends input as JSON   │  JSON input     │   Session per viewer                  │
 │  - acks every frame      │ ──────────────► │ capture.py  mss + numpy + Pillow      │
 └──────────────────────────┘                 │ winput.py   SendInput, cursor, clip   │
                                              │ security.py hashing, tokens, TLS      │
                                              │ indicator.py Tk "session active" bar  │
                                              └───────────────────────────────────────┘
```

## Files

| File | Role |
|---|---|
| `host.py` | Entry point. Config (`data/config.json`), HTTP routes, auth, WebSocket `Session` (streaming loop + input dispatch). |
| `capture.py` | `Capturer`: grabs a monitor with `mss`, detects changed 128 px tiles with numpy, JPEG-encodes changed regions. |
| `winput.py` | Win32 via `ctypes`: DPI awareness, `SendInput` mouse/keyboard, browser `code` → scan code table, cursor shape, clipboard. |
| `security.py` | PBKDF2 password hashing, HMAC session tokens, login rate limiter, LAN allow-list, self-signed cert generation. |
| `indicator.py` | Always-on-top banner while viewers are connected; "Disconnect" revokes sessions. Runs Tk in its own thread. |
| `static/` | Viewer: `index.html`, `app.js`, `style.css`, `login.html`, `login.js`, `favicon.svg`. No inline scripts (strict CSP). |
| `tests/` | `qa_test.py` (unit + live), `browser_test.py` (Playwright). |
| `tools/` | `run_qa.ps1`, `package.ps1`. |

## Wire protocol (`/ws`)

**Host → viewer, binary frame**
```
u8  type = 1
u16 rect_count
repeat rect_count:
  u16 x, u16 y, u16 w, u16 h   (in stream pixels, i.e. after scaling)
  u32 jpeg_length
  jpeg bytes
```
All integers little-endian. The viewer decodes all rects of a frame in parallel
(`createImageBitmap`), draws them in order, then sends `{"t":"ack"}`.

**Host → viewer, JSON**: `init` (size, monitors, current settings, hostname),
`cursor` (CSS cursor name), `clip` (clipboard text), `clipchanged`, `pong`.

**Viewer → host, JSON**

| t | fields | meaning |
|---|---|---|
| `ack` | | frame drawn (flow control) |
| `mm` | x, y | mouse move (stream pixels) |
| `md` / `mu` | b, x, y | button down/up (0 left, 1 middle, 2 right, 3/4 back/forward) |
| `wh` | dy, dx | wheel (Windows units, 120 = one notch) |
| `kd` / `ku` | code, key | key down/up by `KeyboardEvent.code` (physical key) |
| `combo` | codes[] | press all, release in reverse (special keys menu) |
| `text` | s | type unicode text |
| `release` | | release all held keys/buttons (viewer lost focus) |
| `settings` | monitor, scale, quality, fps | change stream; host replies with `init` |
| `refresh` | | force full frame |
| `clipget` / `clipset` | text | clipboard |
| `ping` | ts | RTT measurement |

## Key design decisions

- **Browser viewer** instead of a native client: works on any device, nothing to install.
- **Tile diff + JPEG** instead of a video codec: pure Python, no ffmpeg/GPU deps, very
  low latency, good for desktop content. Unchanged screens cost ~nothing.
- **Idle refinement**: after 0.4 s without changes, regions sent at normal quality are
  re-sent at quality 92 with full chroma, so text becomes crisp.
- **Flow control**: at most 2 un-acked frames in flight, so a slow network drops frame
  rate instead of building up lag.
- **Scan codes, not characters**: `KeyboardEvent.code` → PC scan code, injected with
  `KEYEVENTF_SCANCODE`. The host's own keyboard layout interprets keys, so shortcuts,
  dead keys and layouts like ABNT2 behave exactly like a local keyboard. (Viewer and host
  should use the same layout.) `text` messages use `KEYEVENTF_UNICODE` for arbitrary text.
- **DPI awareness** (per-monitor v2) is set before anything else so capture and input both
  use physical pixels.
- **One capture thread per viewer** (`ThreadPoolExecutor(max_workers=1)`) because `mss`
  handles are thread-bound; input is injected from the asyncio thread.
- **Cursor**: the viewer uses its own local cursor (zero latency); the host only sends the
  cursor *shape*.

## Performance (measured, 1920×1080, i.e. the dev machine)

- Grab + diff of an unchanged screen: ~30–40 ms CPU per frame.
- Full-frame refresh: ~21 full frames/s (~35–50 Mbps at quality 75).
- Typical desktop use only sends small regions: a few Mbps.
