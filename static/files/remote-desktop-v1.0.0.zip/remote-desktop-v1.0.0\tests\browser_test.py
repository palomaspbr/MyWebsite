"""End-to-end test of the real web viewer in Chrome/Edge (headless) via Playwright.

    python tests/browser_test.py <password> [base_url]

Saves screenshots to tests/screenshots/. Briefly moves the mouse and types
into a test window it opens.
"""
import json
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

import winput  # noqa: E402

winput.set_dpi_aware()
from qa_test import TESTWIN, check, results, wait_user_idle  # noqa: E402
from playwright.sync_api import sync_playwright  # noqa: E402

SHOTS = ROOT / "tests" / "screenshots"


def wait_js(page, expr, timeout=5.0):
    """Poll a JS expression (wait_for_function needs eval, which our CSP blocks)."""
    end = time.time() + timeout
    while time.time() < end:
        if page.evaluate(expr):
            return True
        page.wait_for_timeout(100)
    return False


def lan_url():
    import host
    return f"https://{host.local_ips()[0]}:8765"


def main():
    pw_ = sys.argv[1]
    base = sys.argv[2] if len(sys.argv) > 2 else lan_url()
    SHOTS.mkdir(exist_ok=True)
    print(f"== browser: {base}")
    with sync_playwright() as p:
        browser = None
        for channel in ("chrome", "msedge"):
            try:
                browser = p.chromium.launch(channel=channel, headless=True)
                break
            except Exception:
                continue
        assert browser, "no Chrome/Edge found"
        ctx = browser.new_context(ignore_https_errors=True, viewport={"width": 1280, "height": 760})
        page = ctx.new_page()
        console_errors = []
        page.on("console", lambda m: m.type == "error" and console_errors.append(m.text))
        page.on("pageerror", lambda e: console_errors.append(str(e)))

        page.goto(base + "/")
        check("redirected to login", page.url.endswith("/login"))
        page.fill("input[name=password]", "definitely-wrong")
        page.click("button[type=submit]")
        page.wait_for_url("**/login?err=1")
        check("wrong password shows error", page.is_visible("#err") and "Wrong" in page.inner_text("#err"))
        page.screenshot(path=str(SHOTS / "1-login-error.png"))

        page.fill("input[name=password]", pw_)
        page.click("button[type=submit]")
        page.wait_for_url(base + "/")
        page.wait_for_selector("#overlay", state="hidden", timeout=10000)
        page.wait_for_timeout(1500)
        size = page.evaluate("[document.getElementById('screen').width, document.getElementById('screen').height]")
        check("canvas sized to host screen", size[0] > 0 and size[1] > 0, f"{size}")
        # non-black pixels = frames decoded and drawn
        lit = page.evaluate("""() => {
            const c = document.getElementById('screen'), x = c.getContext('2d');
            const d = x.getImageData(0, 0, c.width, c.height).data; let n = 0;
            for (let i = 0; i < d.length; i += 4 * 97) if (d[i] + d[i+1] + d[i+2] > 30) n++;
            return n; }""")
        check("frames rendered on canvas", lit > 100, f"{lit} sampled lit pixels")
        page.wait_for_timeout(1200)
        stats = page.inner_text("#stats")
        check("stats show fps / Mbps / ms", "fps" in stats and "ms" in stats, stats)
        check("host name shown", page.inner_text("#hostname") not in ("", "Connecting…"))
        page.screenshot(path=str(SHOTS / "2-viewer.png"))

        # ---- input through the real viewer -> test window on the host
        out = Path(tempfile.gettempdir()) / "rd_browser_events.json"
        out.unlink(missing_ok=True)
        orig = winput.cursor_pos()
        wait_user_idle()
        proc = subprocess.Popen([sys.executable, "-c", TESTWIN, str(out)])
        try:
            for _ in range(200):  # Tk can take a while to start on a busy machine
                page.wait_for_timeout(100)
                if out.exists():
                    try:
                        data = json.loads(out.read_text("utf-8"))
                        break
                    except Exception:
                        pass
            page.wait_for_timeout(800)  # let the window finish appearing / take focus
            data = json.loads(out.read_text("utf-8"))
            gx, gy, gw, gh = data["geo"]
            box = page.locator("#screen").bounding_box()
            k = box["width"] / size[0]
            cx, cy = gx + gw // 2, gy + gh // 2
            px, py = box["x"] + cx * k, box["y"] + cy * k
            for _attempt in range(3):  # retry if a human moved the real mouse meanwhile
                wait_user_idle(1.0)
                page.mouse.move(px, py)
                page.mouse.click(px, py)
                page.wait_for_timeout(400)
                hx, hy = winput.cursor_pos()
                if abs(hx - cx) <= 3 and abs(hy - cy) <= 3:
                    break
            # viewer is scaled ~0.66x so one CSS pixel ~1.5 host px
            check("viewer click lands on host near target", abs(hx - cx) <= 3 and abs(hy - cy) <= 3,
                  f"host {hx},{hy} vs {cx},{cy}")
            page.mouse.move(px + 3, py + 3)  # a fresh move makes Windows update the cursor shape
            cur = ""
            for _ in range(20):
                page.wait_for_timeout(100)
                cur = page.evaluate("document.getElementById('screen').style.cursor")
                if cur == "text":
                    break
            check("host cursor shape mirrored (I-beam over text box)", cur == "text", cur)
            page.wait_for_timeout(300)
            page.keyboard.press("Shift+KeyH")  # real keyboards send Shift as its own key
            page.keyboard.type("ello")
            page.keyboard.press("Shift+Digit1")
            page.keyboard.press("Enter")
            page.mouse.wheel(0, 300)
            page.wait_for_timeout(800)
            data = json.loads(out.read_text("utf-8"))
            check("keyboard via viewer reaches host app (incl. Shift)", data["text"] == "Hello!\n", repr(data["text"]))
            kinds = [e[0] for e in data["events"]]
            pt = winput.wintypes.POINT(cx, cy)
            under = winput.user32.WindowFromPoint(pt)
            root = winput.user32.GetAncestor(under, 2)
            title = winput.ctypes.create_unicode_buffer(200)
            winput.user32.GetWindowTextW(root, title, 200)
            check("click and wheel via viewer reach host app", "click" in kinds and "wheel" in kinds,
                  f"events={kinds} window under target={title.value!r} geo={data['geo']}")

            page.screenshot(path=str(SHOTS / "3-viewer-testwindow.png"))
        finally:
            proc.kill()
            winput.mouse_move(*orig)

        # ---- settings
        page.select_option("#scale", "0.5")
        page.wait_for_timeout(1000)
        w = page.evaluate("document.getElementById('screen').width")
        check("scale 50% changes stream resolution", abs(w - size[0] / 2) <= 1, str(w))
        page.select_option("#scale", "1")
        page.wait_for_timeout(500)
        page.click("#btnFit")
        check("1:1 toggle", page.inner_text("#btnFit") == "1:1")
        page.click("#btnFit")

        # ---- clipboard panel
        orig_clip = winput.clipboard_get()
        try:
            winput.clipboard_set("clip from host ✓")
            page.click("#btnClip")
            wait_js(page, "document.getElementById('clipText').value.length > 0")
            check("clipboard panel shows host clipboard", page.input_value("#clipText") == "clip from host ✓")
            page.fill("#clipText", "clip from viewer ✓")
            page.click("#clipSet")
            page.wait_for_timeout(400)
            check("viewer sets host clipboard", winput.clipboard_get() == "clip from viewer ✓")
            page.screenshot(path=str(SHOTS / "4-clipboard.png"))
            page.click("[data-close=clipPanel]")
        finally:
            if orig_clip is not None:
                winput.clipboard_set(orig_clip)

        # ---- upload
        tmp = Path(tempfile.gettempdir()) / f"rd_browser_upload_{int(time.time())}.txt"
        tmp.write_text("browser upload", "utf-8")
        page.set_input_files("#fileInput", str(tmp))
        wait_js(page, "document.getElementById('toast').textContent.includes('Saved on host')")
        import host
        cfg = json.loads((host.CONFIG).read_text("utf-8"))
        saved = Path(cfg["upload_dir"]) / tmp.name
        check("file upload from viewer saved on host", saved.exists() and saved.read_text("utf-8") == "browser upload")
        saved.unlink(missing_ok=True)
        tmp.unlink(missing_ok=True)

        # ---- keys menu renders (don't actually fire system shortcuts)
        page.click("#btnKeys")
        check("special keys menu opens", page.is_visible("#keysMenu"))
        page.screenshot(path=str(SHOTS / "5-keys-menu.png"))
        page.keyboard.press("Escape")

        check("no JS errors in console", not console_errors, "; ".join(console_errors[:3]))

        # ---- logout
        page.goto(base + "/logout")
        page.goto(base + "/")
        check("logout ends the session", page.url.endswith("/login"))

        # ---- mobile layout
        m = browser.new_context(ignore_https_errors=True, viewport={"width": 390, "height": 844},
                                is_mobile=True, has_touch=True, device_scale_factor=3)
        mp = m.new_page()
        mp.goto(base + "/login")
        mp.fill("input[name=password]", pw_)
        mp.click("button[type=submit]")
        mp.wait_for_selector("#overlay", state="hidden", timeout=10000)
        mp.wait_for_timeout(1000)
        check("mobile: viewer loads + keyboard button visible", mp.is_visible("#btnKbd"))
        mp.screenshot(path=str(SHOTS / "6-mobile.png"))
        browser.close()

    failed = [n for n, ok in results if not ok]
    print(f"\n{len(results) - len(failed)}/{len(results)} browser checks passed")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
