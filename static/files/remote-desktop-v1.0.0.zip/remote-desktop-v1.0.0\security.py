"""Security helpers: password hashing, signed session tokens, login rate
limiting, network allow-list and self-signed TLS certificates."""
import datetime
import hashlib
import hmac
import ipaddress
import secrets
import socket
import ssl
import time
from pathlib import Path

PBKDF2_ROUNDS = 300_000
SESSION_DAYS = 30
ALPHABET = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # no look-alikes


# ------------------------------------------------------------- passwords
def generate_password(n=12):
    return "".join(secrets.choice(ALPHABET) for _ in range(n))


def hash_password(password, salt=None):
    salt = salt or secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), PBKDF2_ROUNDS).hex()
    return salt, h


def verify_password(password, salt, expected_hash):
    if not salt or not expected_hash:
        return False
    _, h = hash_password(password, salt)
    return hmac.compare_digest(h, expected_hash)


# --------------------------------------------------------- session tokens
def _key(cfg):
    # Changing the password changes the key, which invalidates all sessions.
    return (cfg["secret"] + ":" + cfg.get("password_hash", "")).encode()


def make_token(cfg):
    exp = str(int(time.time()) + SESSION_DAYS * 86400)
    nonce = secrets.token_hex(8)
    msg = f"{exp}.{nonce}"
    sig = hmac.new(_key(cfg), msg.encode(), hashlib.sha256).hexdigest()
    return f"{msg}.{sig}"


def check_token(cfg, token):
    try:
        exp, nonce, sig = token.split(".")
        good = hmac.new(_key(cfg), f"{exp}.{nonce}".encode(), hashlib.sha256).hexdigest()
        return hmac.compare_digest(sig, good) and int(exp) > time.time()
    except Exception:
        return False


# ---------------------------------------------------------- rate limiting
class LoginLimiter:
    """Lock an IP out for LOCK_SECONDS after MAX_FAILS failed attempts."""
    MAX_FAILS = 5
    LOCK_SECONDS = 15 * 60

    def __init__(self):
        self.fails = {}  # ip -> [count, lock_until]

    def locked_for(self, ip):
        rec = self.fails.get(ip)
        if rec and rec[1] > time.time():
            return int(rec[1] - time.time())
        return 0

    def failed(self, ip):
        rec = self.fails.setdefault(ip, [0, 0])
        if rec[1] and rec[1] <= time.time():
            rec[:] = [0, 0]  # previous lock expired
        rec[0] += 1
        if rec[0] >= self.MAX_FAILS:
            rec[1] = time.time() + self.LOCK_SECONDS
        return rec[0]

    def succeeded(self, ip):
        self.fails.pop(ip, None)


# ------------------------------------------------------- network filter
_TAILSCALE_V4 = ipaddress.ip_network("100.64.0.0/10")


def is_local_network(ip):
    """True for loopback, private LAN, link-local and Tailscale/CGNAT ranges."""
    try:
        addr = ipaddress.ip_address(ip.split("%")[0])
    except (ValueError, AttributeError):
        return False
    if getattr(addr, "ipv4_mapped", None):
        addr = addr.ipv4_mapped
    if addr.is_loopback or addr.is_link_local:
        return True
    if addr.version == 4 and addr in _TAILSCALE_V4:
        return True
    return addr.is_private and not addr.is_unspecified


# ------------------------------------------------------- TLS certificate
def ensure_certificate(cert_path: Path, key_path: Path, ips):
    if cert_path.exists() and key_path.exists():
        return
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import NameOID

    key = ec.generate_private_key(ec.SECP256R1())
    host = socket.gethostname()
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, f"Remote Desktop ({host})")])
    alt = [x509.DNSName("localhost"), x509.DNSName(host)]
    for ip in set(ips) | {"127.0.0.1"}:
        try:
            alt.append(x509.IPAddress(ipaddress.ip_address(ip)))
        except ValueError:
            pass
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder()
            .subject_name(name).issuer_name(name)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - datetime.timedelta(days=1))
            .not_valid_after(now + datetime.timedelta(days=3650))
            .add_extension(x509.SubjectAlternativeName(alt), critical=False)
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .sign(key, hashes.SHA256()))
    key_path.write_bytes(key.private_bytes(serialization.Encoding.PEM,
                                           serialization.PrivateFormat.PKCS8,
                                           serialization.NoEncryption()))
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))


def ssl_context(cert_path, key_path):
    ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(cert_path, key_path)
    return ctx


def cert_fingerprint(cert_path):
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes
    cert = x509.load_pem_x509_certificate(Path(cert_path).read_bytes())
    fp = cert.fingerprint(hashes.SHA256()).hex().upper()
    return ":".join(fp[i:i + 2] for i in range(0, 16, 2)) + "..."
