@echo off
rem Starts the remote desktop host. Extra arguments are passed through,
rem e.g.  start.bat --new-password
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe call setup.bat || exit /b 1
title Remote Desktop host
.venv\Scripts\python -u host.py %*
pause
