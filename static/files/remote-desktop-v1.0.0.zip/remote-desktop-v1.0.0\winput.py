"""Win32 helpers: DPI awareness, input injection, cursor shape, clipboard."""
import ctypes
from ctypes import wintypes

user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)


def set_dpi_aware():
    """Make coordinates physical pixels (must run before any capture)."""
    try:
        user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))  # PER_MONITOR_AWARE_V2
    except Exception:
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            user32.SetProcessDPIAware()


# ---------------------------------------------------------------- SendInput
ULONG_PTR = ctypes.c_size_t

INPUT_MOUSE, INPUT_KEYBOARD = 0, 1
KEYEVENTF_EXTENDEDKEY = 0x0001
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004
KEYEVENTF_SCANCODE = 0x0008

MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP = 0x0002, 0x0004
MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP = 0x0008, 0x0010
MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP = 0x0020, 0x0040
MOUSEEVENTF_XDOWN, MOUSEEVENTF_XUP = 0x0080, 0x0100
MOUSEEVENTF_WHEEL = 0x0800
MOUSEEVENTF_HWHEEL = 0x1000
MOUSEEVENTF_VIRTUALDESK = 0x4000
MOUSEEVENTF_ABSOLUTE = 0x8000


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]


class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD), ("wParamH", wintypes.WORD)]


class _INPUTUNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]


class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("u", _INPUTUNION)]


user32.SendInput.argtypes = (wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int)
user32.SendInput.restype = wintypes.UINT
user32.SetCursorPos.argtypes = (ctypes.c_int, ctypes.c_int)
user32.GetSystemMetrics.argtypes = (ctypes.c_int,)


def _send(*inputs):
    arr = (INPUT * len(inputs))(*inputs)
    return user32.SendInput(len(inputs), arr, ctypes.sizeof(INPUT))


def _mouse(flags, data=0, dx=0, dy=0):
    return INPUT(type=INPUT_MOUSE, u=_INPUTUNION(mi=MOUSEINPUT(dx, dy, data & 0xFFFFFFFF, flags, 0, 0)))


def _key(vk=0, scan=0, flags=0):
    return INPUT(type=INPUT_KEYBOARD, u=_INPUTUNION(ki=KEYBDINPUT(vk, scan, flags, 0, 0)))


def virtual_screen():
    """(left, top, width, height) of the whole virtual desktop."""
    return (user32.GetSystemMetrics(76), user32.GetSystemMetrics(77),
            user32.GetSystemMetrics(78), user32.GetSystemMetrics(79))


def mouse_move(x, y):
    """Move to absolute virtual-desktop pixel (x, y)."""
    vl, vt, vw, vh = virtual_screen()
    x = min(max(int(x), vl), vl + vw - 1)
    y = min(max(int(y), vt), vt + vh - 1)
    user32.SetCursorPos(x, y)
    # Also emit a SendInput move so apps relying on raw input notice it.
    nx = int(round((x - vl) * 65535 / max(vw - 1, 1)))
    ny = int(round((y - vt) * 65535 / max(vh - 1, 1)))
    _send(_mouse(MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK, 0, nx, ny))
    user32.SetCursorPos(x, y)  # exact final position (normalisation can be off by 1px)


_BUTTONS = {
    0: (MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP, 0),
    1: (MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP, 0),
    2: (MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP, 0),
    3: (MOUSEEVENTF_XDOWN, MOUSEEVENTF_XUP, 1),  # browser button 3 = back = XBUTTON1
    4: (MOUSEEVENTF_XDOWN, MOUSEEVENTF_XUP, 2),
}


def mouse_button(button, down):
    if button not in _BUTTONS:
        return
    d, u, data = _BUTTONS[button]
    _send(_mouse(d if down else u, data))


def mouse_wheel(dy=0, dx=0):
    if dy:
        _send(_mouse(MOUSEEVENTF_WHEEL, int(dy)))
    if dx:
        _send(_mouse(MOUSEEVENTF_HWHEEL, int(dx)))


# Browser KeyboardEvent.code -> (scan code, extended).  Layout-independent:
# the host's own keyboard layout interprets the physical key.
SCAN = {
    "Escape": (0x01, 0), "Digit1": (0x02, 0), "Digit2": (0x03, 0), "Digit3": (0x04, 0),
    "Digit4": (0x05, 0), "Digit5": (0x06, 0), "Digit6": (0x07, 0), "Digit7": (0x08, 0),
    "Digit8": (0x09, 0), "Digit9": (0x0A, 0), "Digit0": (0x0B, 0), "Minus": (0x0C, 0),
    "Equal": (0x0D, 0), "Backspace": (0x0E, 0), "Tab": (0x0F, 0),
    "KeyQ": (0x10, 0), "KeyW": (0x11, 0), "KeyE": (0x12, 0), "KeyR": (0x13, 0), "KeyT": (0x14, 0),
    "KeyY": (0x15, 0), "KeyU": (0x16, 0), "KeyI": (0x17, 0), "KeyO": (0x18, 0), "KeyP": (0x19, 0),
    "BracketLeft": (0x1A, 0), "BracketRight": (0x1B, 0), "Enter": (0x1C, 0), "ControlLeft": (0x1D, 0),
    "KeyA": (0x1E, 0), "KeyS": (0x1F, 0), "KeyD": (0x20, 0), "KeyF": (0x21, 0), "KeyG": (0x22, 0),
    "KeyH": (0x23, 0), "KeyJ": (0x24, 0), "KeyK": (0x25, 0), "KeyL": (0x26, 0),
    "Semicolon": (0x27, 0), "Quote": (0x28, 0), "Backquote": (0x29, 0), "ShiftLeft": (0x2A, 0),
    "Backslash": (0x2B, 0), "KeyZ": (0x2C, 0), "KeyX": (0x2D, 0), "KeyC": (0x2E, 0), "KeyV": (0x2F, 0),
    "KeyB": (0x30, 0), "KeyN": (0x31, 0), "KeyM": (0x32, 0), "Comma": (0x33, 0), "Period": (0x34, 0),
    "Slash": (0x35, 0), "ShiftRight": (0x36, 0), "NumpadMultiply": (0x37, 0), "AltLeft": (0x38, 0),
    "Space": (0x39, 0), "CapsLock": (0x3A, 0),
    "F1": (0x3B, 0), "F2": (0x3C, 0), "F3": (0x3D, 0), "F4": (0x3E, 0), "F5": (0x3F, 0),
    "F6": (0x40, 0), "F7": (0x41, 0), "F8": (0x42, 0), "F9": (0x43, 0), "F10": (0x44, 0),
    "ScrollLock": (0x46, 0), "Numpad7": (0x47, 0), "Numpad8": (0x48, 0), "Numpad9": (0x49, 0),
    "NumpadSubtract": (0x4A, 0), "Numpad4": (0x4B, 0), "Numpad5": (0x4C, 0), "Numpad6": (0x4D, 0),
    "NumpadAdd": (0x4E, 0), "Numpad1": (0x4F, 0), "Numpad2": (0x50, 0), "Numpad3": (0x51, 0),
    "Numpad0": (0x52, 0), "NumpadDecimal": (0x53, 0), "IntlBackslash": (0x56, 0),
    "F11": (0x57, 0), "F12": (0x58, 0), "NumpadEqual": (0x59, 0),
    "F13": (0x64, 0), "F14": (0x65, 0), "F15": (0x66, 0), "F16": (0x67, 0), "F17": (0x68, 0),
    "F18": (0x69, 0), "F19": (0x6A, 0), "F20": (0x6B, 0), "F21": (0x6C, 0), "F22": (0x6D, 0),
    "F23": (0x6E, 0), "F24": (0x76, 0),
    "KanaMode": (0x70, 0), "IntlRo": (0x73, 0), "Convert": (0x79, 0), "NonConvert": (0x7B, 0),
    "IntlYen": (0x7D, 0), "NumpadComma": (0x7E, 0),
    # extended (E0-prefixed)
    "NumpadEnter": (0x1C, 1), "ControlRight": (0x1D, 1), "NumpadDivide": (0x35, 1),
    "AltRight": (0x38, 1), "Home": (0x47, 1), "ArrowUp": (0x48, 1), "PageUp": (0x49, 1),
    "ArrowLeft": (0x4B, 1), "ArrowRight": (0x4D, 1), "End": (0x4F, 1), "ArrowDown": (0x50, 1),
    "PageDown": (0x51, 1), "Insert": (0x52, 1), "Delete": (0x53, 1), "MetaLeft": (0x5B, 1),
    "MetaRight": (0x5C, 1), "OSLeft": (0x5B, 1), "OSRight": (0x5C, 1), "ContextMenu": (0x5D, 1),
    "AudioVolumeMute": (0x20, 1), "AudioVolumeDown": (0x2E, 1), "AudioVolumeUp": (0x30, 1),
    "MediaPlayPause": (0x22, 1), "MediaStop": (0x24, 1), "MediaTrackNext": (0x19, 1),
    "MediaTrackPrevious": (0x10, 1), "BrowserHome": (0x32, 1), "BrowserBack": (0x6A, 1),
    "BrowserForward": (0x69, 1), "BrowserRefresh": (0x67, 1), "BrowserSearch": (0x65, 1),
}
# Keys that behave better injected by virtual-key code.
VK = {"Pause": (0x13, 0), "NumLock": (0x90, 1), "PrintScreen": (0x2C, 1)}


def key_event(code, down):
    """Inject a physical key by its browser `code`. Returns True if known."""
    up = 0 if down else KEYEVENTF_KEYUP
    if code in SCAN:
        sc, ext = SCAN[code]
        _send(_key(0, sc, KEYEVENTF_SCANCODE | up | (KEYEVENTF_EXTENDEDKEY if ext else 0)))
        return True
    if code in VK:
        vk, ext = VK[code]
        sc = user32.MapVirtualKeyW(vk, 0)
        _send(_key(vk, sc, up | (KEYEVENTF_EXTENDEDKEY if ext else 0)))
        return True
    return False


def type_text(text):
    """Type arbitrary unicode text (independent of keyboard layout)."""
    text = text.replace("\r\n", "\n")
    for ch in text:
        if ch == "\n":
            key_event("Enter", True)
            key_event("Enter", False)
            continue
        if ch == "\t":
            key_event("Tab", True)
            key_event("Tab", False)
            continue
        data = ch.encode("utf-16-le")
        for i in range(0, len(data), 2):
            unit = int.from_bytes(data[i:i + 2], "little")
            _send(_key(0, unit, KEYEVENTF_UNICODE), _key(0, unit, KEYEVENTF_UNICODE | KEYEVENTF_KEYUP))


# ------------------------------------------------------------- cursor shape
class CURSORINFO(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.DWORD), ("flags", wintypes.DWORD),
                ("hCursor", wintypes.HANDLE), ("ptScreenPos", wintypes.POINT)]


user32.LoadCursorW.argtypes = (wintypes.HINSTANCE, ctypes.c_void_p)
user32.LoadCursorW.restype = wintypes.HANDLE
user32.GetCursorInfo.argtypes = (ctypes.POINTER(CURSORINFO),)

_CURSOR_IDS = {
    32512: "default", 32513: "text", 32514: "wait", 32515: "crosshair", 32516: "default",
    32642: "nwse-resize", 32643: "nesw-resize", 32644: "ew-resize", 32645: "ns-resize",
    32646: "move", 32648: "not-allowed", 32649: "pointer", 32650: "progress", 32651: "help",
}
_cursor_map = None


def cursor_state():
    """Return (css_cursor_name, x, y, visible)."""
    global _cursor_map
    if _cursor_map is None:
        _cursor_map = {}
        for cid, name in _CURSOR_IDS.items():
            h = user32.LoadCursorW(None, ctypes.c_void_p(cid))
            if h:
                _cursor_map[h] = name
    ci = CURSORINFO()
    ci.cbSize = ctypes.sizeof(CURSORINFO)
    if not user32.GetCursorInfo(ctypes.byref(ci)):
        return "default", 0, 0, True
    visible = bool(ci.flags & 1)
    name = _cursor_map.get(ci.hCursor, "default") if visible else "none"
    return name, ci.ptScreenPos.x, ci.ptScreenPos.y, visible


def cursor_pos():
    pt = wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(pt))
    return pt.x, pt.y


# ---------------------------------------------------------------- clipboard
CF_UNICODETEXT = 13
GMEM_MOVEABLE = 0x0002
user32.OpenClipboard.argtypes = (wintypes.HWND,)
user32.GetClipboardData.argtypes = (wintypes.UINT,)
user32.GetClipboardData.restype = wintypes.HANDLE
user32.SetClipboardData.argtypes = (wintypes.UINT, wintypes.HANDLE)
user32.SetClipboardData.restype = wintypes.HANDLE
user32.GetClipboardSequenceNumber.restype = wintypes.DWORD
kernel32.GlobalLock.argtypes = (wintypes.HGLOBAL,)
kernel32.GlobalLock.restype = ctypes.c_void_p
kernel32.GlobalUnlock.argtypes = (wintypes.HGLOBAL,)
kernel32.GlobalAlloc.argtypes = (wintypes.UINT, ctypes.c_size_t)
kernel32.GlobalAlloc.restype = wintypes.HGLOBAL


def _open_clipboard():
    import time
    for _ in range(20):
        if user32.OpenClipboard(None):
            return True
        time.sleep(0.01)
    return False


def clipboard_get():
    if not _open_clipboard():
        return None
    try:
        h = user32.GetClipboardData(CF_UNICODETEXT)
        if not h:
            return ""
        p = kernel32.GlobalLock(h)
        try:
            return ctypes.wstring_at(p)
        finally:
            kernel32.GlobalUnlock(h)
    finally:
        user32.CloseClipboard()


def clipboard_set(text):
    data = text.encode("utf-16-le") + b"\x00\x00"
    if not _open_clipboard():
        return False
    try:
        user32.EmptyClipboard()
        h = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(data))
        p = kernel32.GlobalLock(h)
        ctypes.memmove(p, data, len(data))
        kernel32.GlobalUnlock(h)
        return bool(user32.SetClipboardData(CF_UNICODETEXT, h))
    finally:
        user32.CloseClipboard()


def clipboard_seq():
    return user32.GetClipboardSequenceNumber()
