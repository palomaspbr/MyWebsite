'use strict';
(() => {
  const q = new URLSearchParams(location.search);
  const err = document.getElementById('err');
  const locked = parseInt(q.get('locked') || '0', 10);
  if (locked > 0) {
    err.textContent = `Too many failed attempts. Try again in ${Math.ceil(locked / 60)} min.`;
    err.hidden = false;
  } else if (q.get('err')) {
    err.textContent = 'Wrong password.';
    err.hidden = false;
  }
})();
