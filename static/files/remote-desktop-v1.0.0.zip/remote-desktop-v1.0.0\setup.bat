@echo off
rem One-time setup: creates a private Python environment and installs dependencies.
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python 3.10+ is required. Install it from https://www.python.org/downloads/
  echo ^(tick "Add python.exe to PATH" during install^) and run this again.
  pause
  exit /b 1
)
if not exist .venv\Scripts\python.exe (
  echo Creating virtual environment...
  python -m venv .venv || goto :fail
)
echo Installing dependencies...
.venv\Scripts\python -m pip install --disable-pip-version-check -q --upgrade pip
.venv\Scripts\python -m pip install --disable-pip-version-check -q -r requirements.txt || goto :fail
echo.
echo Setup complete. Run start.bat to start the host.
exit /b 0
:fail
echo Setup FAILED - see the messages above.
pause
exit /b 1
