# Security model

## What it protects against

| Threat | Mitigation |
|---|---|
| Someone on the same Wi-Fi sniffing traffic | TLS (HTTPS/WSS) for everything. |
| Password guessing | 12-char random default (~68 bits), PBKDF2-SHA256 (300k rounds), 1.5 s delay per failure, 5 failures ⇒ 15 min lockout per IP. |
| Stolen `config.json` revealing the password | Only a salted hash is stored. |
| Internet attackers (accidental port-forward / UPnP) | Requests from non-private IPs get HTTP 403 before any page or login is served. |
| Malicious website you visit driving your session (CSRF / cross-site WebSocket hijacking) | `SameSite=Strict` cookie, `Origin` check on `/ws` and `/upload`. |
| Clickjacking | `X-Frame-Options: DENY`, `frame-ancestors 'none'`. |
| Script injection | Strict CSP (`script-src 'self'`, no inline scripts, no eval). |
| Path traversal via uploads | Filenames reduced to a safe basename; reserved device names rejected; never overwrites. |
| Forgotten / unwanted session | Cookies expire after 30 days; **Disconnect** button or `--new-password` revokes all. |
| Silent spying | Always-on-top banner on the host while connected (unless `--no-indicator`), console log of every login/connection. |

## What it does NOT protect against

- **Someone who already knows the password and is on your network** — they get full control. Use a strong password and change it if leaked (`start.bat --new-password`).
- **Malware already on the host or the viewer device.**
- **Man-in-the-middle on the very first connection**: the certificate is self-signed, so the browser can't verify it automatically. Compare the fingerprint printed by the host with the browser's certificate details the first time if you're on an untrusted network.
- **A compromised device inside your LAN/VPN** (the allow-list trusts private addresses; the password is still required).
- **Running with `--allow-public-ips`**: then the only barrier is the password + lockout. Prefer Tailscale/VPN.

## Recommendations

1. Keep the default HTTPS and LAN-only settings.
2. For remote access use Tailscale (or another VPN), never port forwarding.
3. Use `allow-firewall.bat` — it opens the port only for the local subnet on *Private* networks.
4. Don't share the `data/` folder.
5. Don't run the host as Administrator unless you need to control elevated windows.

## Reporting

This is a small hobby project; if you find a problem, open an issue on the site's repository.
