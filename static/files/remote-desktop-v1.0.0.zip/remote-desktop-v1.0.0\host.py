"""Remote desktop host: run this on the PC you want to control.

    python host.py                   # HTTPS on port 8765
    python host.py --password X      # set a new password
    python host.py --new-password    # generate a new random password
    python host.py --port 9000

Then open https://<this-pc-ip>:8765 in a browser on another device on the
same network (or over Tailscale/VPN).
"""
import argparse
import asyncio
import concurrent.futures
import json
import os
import socket
import sys
import time
from pathlib import Path

import winput

winput.set_dpi_aware()  # before any capture / window creation

from aiohttp import web, WSMsgType  # noqa: E402

import security  # noqa: E402
from capture import Capturer  # noqa: E402

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
DATA = Path(os.environ.get("RD_DATA_DIR") or ROOT / "data")  # per-install secrets: never share
CONFIG = DATA / "config.json"
CERT, KEY = DATA / "cert.pem", DATA / "key.pem"
COOKIE = "rd_session"
VERSION = "1.0.0"


def log(*a):
    print(f"[{time.strftime('%H:%M:%S')}]", *a, flush=True)


# ------------------------------------------------------------------ config
def load_config():
    DATA.mkdir(exist_ok=True)
    try:
        cfg = json.loads(CONFIG.read_text("utf-8")) if CONFIG.exists() else {}
    except Exception:
        cfg = {}
    cfg.setdefault("secret", security.secrets.token_hex(32))
    cfg.setdefault("port", 8765)
    cfg.setdefault("upload_dir", str(Path.home() / "Downloads" / "RemoteDesktop"))
    cfg.setdefault("allow_public_ips", False)
    cfg.setdefault("https", True)
    return cfg


def save_config(cfg):
    DATA.mkdir(exist_ok=True)
    CONFIG.write_text(json.dumps(cfg, indent=2), "utf-8")


def set_password(cfg, password):
    cfg["salt"], cfg["password_hash"] = security.hash_password(password)


def local_ips():
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.add(s.getsockname()[0])
        s.close()
    except Exception:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except Exception:
        pass
    ips.discard("127.0.0.1")
    return sorted(ips) or ["127.0.0.1"]


def is_authed(request):
    return security.check_token(request.app["cfg"], request.cookies.get(COOKIE, ""))


# -------------------------------------------------------------- middleware
@web.middleware
async def guard(request, handler):
    cfg = request.app["cfg"]
    ip = request.remote or ""
    if not cfg["allow_public_ips"] and not security.is_local_network(ip):
        log(f"BLOCKED connection from non-local address {ip}")
        return web.Response(status=403, text="Forbidden")
    try:
        resp = await handler(request)
    except web.HTTPException as exc:  # redirects/errors are raised; still add headers
        _security_headers(exc)
        raise
    _security_headers(resp)
    return resp


def _security_headers(resp):
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("Referrer-Policy", "no-referrer")
    resp.headers.setdefault("Content-Security-Policy",
                            "default-src 'self'; img-src 'self' blob: data:; connect-src 'self' ws: wss:; "
                            "style-src 'self'; script-src 'self'; frame-ancestors 'none'; base-uri 'none'; "
                            "form-action 'self'")


# ------------------------------------------------------------------ routes
async def index(request):
    if not is_authed(request):
        raise web.HTTPFound("/login")
    return web.FileResponse(STATIC / "index.html", headers={"Cache-Control": "no-store"})


async def login_page(request):
    if is_authed(request):
        raise web.HTTPFound("/")
    return web.FileResponse(STATIC / "login.html", headers={"Cache-Control": "no-store"})


async def login_post(request):
    app = request.app
    cfg, limiter = app["cfg"], app["limiter"]
    ip = request.remote or ""
    wait = limiter.locked_for(ip)
    if wait:
        log(f"login attempt from locked-out {ip} ({wait}s left)")
        raise web.HTTPFound(f"/login?locked={wait}")
    data = await request.post()
    pw = str(data.get("password", ""))[:256]
    ok = await asyncio.get_running_loop().run_in_executor(
        None, security.verify_password, pw, cfg.get("salt"), cfg.get("password_hash"))
    if ok:
        limiter.succeeded(ip)
        log(f"login OK from {ip}")
        resp = web.HTTPFound("/")
        resp.set_cookie(COOKIE, security.make_token(cfg), max_age=security.SESSION_DAYS * 86400,
                        httponly=True, samesite="Strict", secure=request.secure)
        raise resp
    n = limiter.failed(ip)
    log(f"login FAILED from {ip} (attempt {n})")
    await asyncio.sleep(1.5)  # slow down guessing
    wait = limiter.locked_for(ip)
    raise web.HTTPFound(f"/login?locked={wait}" if wait else "/login?err=1")


async def logout(request):
    resp = web.HTTPFound("/login")
    resp.del_cookie(COOKIE)
    raise resp


async def upload(request):
    if not is_authed(request):
        raise web.HTTPUnauthorized()
    if not origin_ok(request):
        raise web.HTTPForbidden()
    dest = Path(request.app["cfg"]["upload_dir"])
    dest.mkdir(parents=True, exist_ok=True)
    reader = await request.multipart()
    saved = []
    async for part in reader:
        if part.name != "file" or not part.filename:
            continue
        target = dest / safe_filename(part.filename)
        stem, suffix, n = target.stem, target.suffix, 1
        while target.exists():
            target = dest / f"{stem} ({n}){suffix}"
            n += 1
        with open(target, "wb") as f:
            while chunk := await part.read_chunk(1 << 20):
                f.write(chunk)
        saved.append(target.name)
        log(f"file received from {request.remote}: {target}")
    return web.json_response({"saved": saved})


_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(10)), *(f"LPT{i}" for i in range(10))}


def safe_filename(name):
    """Reduce an uploaded filename to a plain, harmless basename."""
    name = str(name).replace("\\", "/").split("/")[-1]
    name = "".join(c for c in name if c not in '<>:"|?*' and ord(c) >= 32).strip(" .")
    if not name or name.split(".")[0].upper() in _RESERVED:
        name = "upload_" + (name or "file")
    return name[:200]


def origin_ok(request):
    """Reject cross-site requests (a malicious page can't drive the viewer)."""
    origin = request.headers.get("Origin")
    if origin is None:
        return True
    return origin.split("://", 1)[-1] == request.host


# --------------------------------------------------------------- websocket
class Session:
    MAX_IN_FLIGHT = 2

    def __init__(self, ws, ip):
        self.ws = ws
        self.ip = ip
        self.cap = Capturer()
        self.pool = concurrent.futures.ThreadPoolExecutor(max_workers=1, thread_name_prefix="capture")
        self.fps = 30
        self.in_flight = 0
        self.acked = asyncio.Event()
        self.acked.set()
        self.keys_down = set()
        self.buttons_down = set()
        self.last_cursor = None
        self.clip_seq = winput.clipboard_seq()
        self.closed = False

    async def run_in_capture(self, fn, *args):
        return await asyncio.get_running_loop().run_in_executor(self.pool, fn, *args)

    async def send_init(self):
        mons = await self.run_in_capture(self.cap.monitors)
        _mon, ow, oh = await self.run_in_capture(self.cap.geometry)
        await self.ws.send_json({
            "t": "init", "width": ow, "height": oh, "monitors": mons,
            "monitor": self.cap.monitor_index, "scale": self.cap.scale,
            "quality": self.cap.quality, "fps": self.fps, "host": socket.gethostname(),
        })

    async def stream(self):
        loop = asyncio.get_running_loop()
        while not self.closed:
            t0 = loop.time()
            while self.in_flight >= self.MAX_IN_FLIGHT and not self.closed:
                self.acked.clear()
                try:
                    await asyncio.wait_for(self.acked.wait(), 5)
                except asyncio.TimeoutError:
                    self.in_flight = 0  # viewer stalled; resync
            if self.closed:
                break
            try:
                msg, _info = await self.run_in_capture(self.cap.grab)
            except Exception as e:  # display change, secure desktop (UAC/lock screen)...
                log("capture error:", e)
                await self.run_in_capture(self.cap.reset)
                await asyncio.sleep(0.5)
                continue
            if msg is not None:
                self.in_flight += 1
                await self.ws.send_bytes(msg)
            await self.poll_extras()
            await asyncio.sleep(max(1 / self.fps - (loop.time() - t0), 0.002))

    async def poll_extras(self):
        name, _x, _y, _vis = winput.cursor_state()
        if name != self.last_cursor:
            self.last_cursor = name
            await self.ws.send_json({"t": "cursor", "c": name})
        seq = winput.clipboard_seq()
        if seq != self.clip_seq:
            self.clip_seq = seq
            await self.ws.send_json({"t": "clipchanged"})

    async def handle(self, m):
        t = m.get("t")
        if t == "ack":
            self.in_flight = max(0, self.in_flight - 1)
            self.acked.set()
        elif t == "mm":
            winput.mouse_move(*self.cap.to_screen(float(m["x"]), float(m["y"])))
        elif t in ("md", "mu"):
            if "x" in m:
                winput.mouse_move(*self.cap.to_screen(float(m["x"]), float(m["y"])))
            down = t == "md"
            b = int(m.get("b", 0))
            winput.mouse_button(b, down)
            (self.buttons_down.add if down else self.buttons_down.discard)(b)
        elif t == "wh":
            winput.mouse_wheel(int(m.get("dy", 0)), int(m.get("dx", 0)))
        elif t in ("kd", "ku"):
            down = t == "kd"
            code = str(m.get("code", ""))
            if winput.key_event(code, down):
                (self.keys_down.add if down else self.keys_down.discard)(code)
            elif down and len(str(m.get("key", ""))) == 1:
                winput.type_text(m["key"])
        elif t == "combo":
            codes = [str(c) for c in m.get("codes", [])][:8]
            for c in codes:
                winput.key_event(c, True)
            for c in reversed(codes):
                winput.key_event(c, False)
        elif t == "text":
            await asyncio.get_running_loop().run_in_executor(None, winput.type_text, str(m.get("s", ""))[:100_000])
        elif t == "release":
            self.release_all()
        elif t == "settings":
            if "fps" in m:
                self.fps = min(max(int(m["fps"]), 1), 60)
            mon = m.get("monitor")
            await self.run_in_capture(lambda: self.cap.configure(
                int(mon) if mon is not None else None, m.get("scale"), m.get("quality")))
            await self.send_init()
        elif t == "refresh":
            await self.run_in_capture(self.cap.reset)
        elif t == "clipget":
            await self.ws.send_json({"t": "clip", "text": winput.clipboard_get() or ""})
        elif t == "clipset":
            winput.clipboard_set(str(m.get("text", ""))[:10_000_000])
            self.clip_seq = winput.clipboard_seq()
        elif t == "ping":
            await self.ws.send_json({"t": "pong", "ts": m.get("ts")})

    def release_all(self):
        for code in list(self.keys_down):
            winput.key_event(code, False)
        self.keys_down.clear()
        for b in list(self.buttons_down):
            winput.mouse_button(b, False)
        self.buttons_down.clear()

    def close(self):
        if self.closed:
            return
        self.closed = True
        self.acked.set()
        self.release_all()
        self.pool.submit(self.cap.close)
        self.pool.shutdown(wait=False)


def sessions_changed(app):
    ind = app.get("indicator")
    if ind:
        ind.update([s.ip for s in app["sessions"]])


async def ws_handler(request):
    if not is_authed(request):
        raise web.HTTPUnauthorized()
    if not origin_ok(request):
        log(f"rejected cross-origin websocket from {request.remote}: {request.headers.get('Origin')}")
        raise web.HTTPForbidden()
    ws = web.WebSocketResponse(heartbeat=20, max_msg_size=32 * 1024 * 1024)
    await ws.prepare(request)
    ip = request.remote
    log(f"viewer CONNECTED: {ip}")
    s = Session(ws, ip)
    app = request.app
    app["sessions"].add(s)
    sessions_changed(app)
    streamer = None
    try:
        await s.send_init()
        streamer = asyncio.create_task(s.stream())
        async for msg in ws:
            if msg.type == WSMsgType.TEXT:
                try:
                    await s.handle(json.loads(msg.data))
                except Exception as e:
                    log("bad message:", type(e).__name__, e)
            elif msg.type == WSMsgType.ERROR:
                break
    finally:
        s.close()
        if streamer:
            streamer.cancel()
        app["sessions"].discard(s)
        sessions_changed(app)
        log(f"viewer disconnected: {ip}")
    return ws


async def kick_all(app):
    for s in list(app["sessions"]):
        s.close()
        await s.ws.close(code=4001, message=b"Disconnected by host")


async def on_startup(app):
    loop = asyncio.get_running_loop()
    if not app.get("no_indicator"):
        from indicator import Indicator

        def disconnect():
            log("host clicked Disconnect - all sessions revoked, viewers must log in again")
            # rotating the secret invalidates every issued session cookie
            app["cfg"]["secret"] = security.secrets.token_hex(32)
            save_config(app["cfg"])
            asyncio.run_coroutine_threadsafe(kick_all(app), loop)
        app["indicator"] = Indicator(disconnect)


async def on_shutdown(app):
    await kick_all(app)


def make_app(cfg, no_indicator=False):
    app = web.Application(client_max_size=4 * 1024 ** 3, middlewares=[guard])
    app["cfg"] = cfg
    app["sessions"] = set()
    app["limiter"] = security.LoginLimiter()
    app["no_indicator"] = no_indicator
    app.router.add_get("/", index)
    app.router.add_get("/login", login_page)
    app.router.add_post("/login", login_post)
    app.router.add_get("/logout", logout)
    app.router.add_get("/favicon.ico", lambda r: web.FileResponse(STATIC / "favicon.svg", headers={"Content-Type": "image/svg+xml"}))
    app.router.add_post("/upload", upload)
    app.router.add_get("/ws", ws_handler)
    app.router.add_static("/static", STATIC)
    app.on_startup.append(on_startup)
    app.on_shutdown.append(on_shutdown)
    return app


def main():
    ap = argparse.ArgumentParser(description="Remote desktop host")
    ap.add_argument("--port", type=int)
    ap.add_argument("--bind", default="0.0.0.0", help="address to listen on (default all)")
    ap.add_argument("--password", help="set a new password (min 8 characters)")
    ap.add_argument("--new-password", action="store_true", help="generate a new random password")
    ap.add_argument("--http", action="store_true", help="disable HTTPS (not recommended)")
    ap.add_argument("--allow-public-ips", action="store_true",
                    help="accept connections from outside the local network (dangerous)")
    ap.add_argument("--no-indicator", action="store_true", help="hide the on-screen session banner")
    args = ap.parse_args()

    cfg = load_config()
    shown_password = None
    if args.password is not None:
        if len(args.password) < 8:
            sys.exit("Password must be at least 8 characters.")
        set_password(cfg, args.password)
        shown_password = args.password
    elif args.new_password or not cfg.get("password_hash"):
        shown_password = security.generate_password()
        set_password(cfg, shown_password)
    if args.port:
        cfg["port"] = args.port
    if args.http:
        cfg["https"] = False
    if args.allow_public_ips:
        cfg["allow_public_ips"] = True
    save_config(cfg)

    ips = local_ips()
    ssl_ctx = None
    if cfg["https"]:
        security.ensure_certificate(CERT, KEY, ips)
        ssl_ctx = security.ssl_context(CERT, KEY)
    scheme = "https" if ssl_ctx else "http"
    port = cfg["port"]

    print("=" * 62)
    print(f" Remote Desktop host v{VERSION}")
    for ip in ips:
        print(f"   open:  {scheme}://{ip}:{port}")
    if shown_password:
        print(f"   password: {shown_password}")
        print("   (write it down - it is stored only as a hash and won't be shown again;")
        print("    run with --new-password or --password to change it)")
    else:
        print("   password: (unchanged - use --new-password or --password to reset)")
    if ssl_ctx:
        print(f"   certificate fingerprint: {security.cert_fingerprint(CERT)}")
        print("   (browser will warn about the self-signed certificate the first time:")
        print("    choose Advanced -> Continue)")
    if cfg["allow_public_ips"]:
        print("   WARNING: accepting connections from ANY address (allow_public_ips)")
    else:
        print("   accepting only local network / VPN addresses")
    print(f"   received files go to: {cfg['upload_dir']}")
    print(" Ctrl+C to stop")
    print("=" * 62, flush=True)
    web.run_app(make_app(cfg, args.no_indicator), host=args.bind, port=port,
                ssl_context=ssl_ctx, print=None, access_log=None)


if __name__ == "__main__":
    main()
