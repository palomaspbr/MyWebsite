"""QA tests. Unit tests always run; integration tests need a running host:

    python host.py --password qa-test-pass-123     (in another terminal)
    python tests/qa_test.py --live qa-test-pass-123

NOTE: live tests briefly move the mouse, type into a test window they open,
and temporarily use the clipboard (restored afterwards).
"""
import asyncio
import io
import json
import os
import ssl
import struct
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import winput  # noqa: E402

winput.set_dpi_aware()

import security  # noqa: E402
from capture import Capturer, HDR, RECT  # noqa: E402
from PIL import Image  # noqa: E402

results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(("  PASS " if cond else "  FAIL ") + name + (f"  [{detail}]" if detail else ""), flush=True)


def parse_frame(msg):
    typ, n = HDR.unpack_from(msg, 0)
    off = HDR.size
    rects = []
    for _ in range(n):
        x, y, w, h, ln = RECT.unpack_from(msg, off)
        off += RECT.size
        img = Image.open(io.BytesIO(msg[off:off + ln]))
        img.load()
        rects.append((x, y, w, h, img))
        off += ln
    assert off == len(msg), "trailing bytes"
    return typ, rects


# ---------------------------------------------------------------- unit
def unit_tests():
    print("== unit: security")
    for ip, exp in [("127.0.0.1", True), ("192.168.1.20", True), ("10.0.0.5", True), ("172.20.1.1", True),
                    ("100.101.102.103", True), ("::1", True), ("fe80::1%12", True), ("fd7a:115c:a1e0::1", True),
                    ("::ffff:192.168.0.3", True), ("8.8.8.8", False), ("200.150.10.1", False),
                    ("2804:14c::1", False), ("::ffff:8.8.8.8", False), ("", False), ("garbage", False)]:
        check(f"is_local_network({ip!r}) == {exp}", security.is_local_network(ip) == exp)

    salt, h = security.hash_password("correct horse")
    check("password verifies", security.verify_password("correct horse", salt, h))
    check("wrong password rejected", not security.verify_password("Correct horse", salt, h))
    check("generated password is 12 chars", len(security.generate_password()) == 12)

    cfg = {"secret": "s" * 64, "password_hash": h}
    tok = security.make_token(cfg)
    check("token valid", security.check_token(cfg, tok))
    check("tampered token rejected", not security.check_token(cfg, tok[:-1] + ("0" if tok[-1] != "0" else "1")))
    exp_tok = tok.split(".")
    check("forged expiry rejected", not security.check_token(cfg, f"{int(exp_tok[0]) + 999}.{exp_tok[1]}.{exp_tok[2]}"))
    check("token revoked by password change", not security.check_token({**cfg, "password_hash": "x"}, tok))
    check("token revoked by secret rotation", not security.check_token({**cfg, "secret": "t" * 64}, tok))
    check("empty token rejected", not security.check_token(cfg, ""))

    lim = security.LoginLimiter()
    for _ in range(4):
        lim.failed("1.2.3.4")
    check("not locked after 4 fails", lim.locked_for("1.2.3.4") == 0)
    lim.failed("1.2.3.4")
    check("locked after 5 fails", lim.locked_for("1.2.3.4") > 800)
    check("other IP unaffected", lim.locked_for("1.2.3.5") == 0)

    print("== unit: upload filename sanitising")
    import host
    for raw, exp in [("..\\..\\Windows\\evil.exe", "evil.exe"), ("../../etc/passwd", "passwd"),
                     ("C:\\Users\\x\\a.txt", "a.txt"), ("CON.txt", "upload_CON.txt"), ("..", "upload_file"),
                     ("a:b?.txt", "ab.txt"), ("normal file (1).pdf", "normal file (1).pdf"), ("", "upload_file")]:
        got = host.safe_filename(raw)
        check(f"safe_filename({raw!r}) -> {exp!r}", got == exp, got)

    print("== unit: input key table")
    check("all letters mapped", all(f"Key{c}" in winput.SCAN for c in "ABCDEFGHIJKLMNOPQRSTUVWXYZ"))
    check("ABNT2 extra key (IntlRo) mapped", "IntlRo" in winput.SCAN and "NumpadComma" in winput.SCAN)

    print("== unit: capture")
    cap = Capturer()
    mons = cap.monitors()
    check("monitors detected", len(mons) >= 2, f"{len(mons) - 1} monitor(s)")
    t = time.perf_counter()
    msg, info = cap.grab()
    t_full = (time.perf_counter() - t) * 1000
    typ, rects = parse_frame(msg)
    _mon, ow, oh = cap.geometry()
    check("first frame is full screen", len(rects) == 1 and rects[0][:4] == (0, 0, ow, oh),
          f"{ow}x{oh}, {len(msg) // 1024} KB, {t_full:.0f} ms")
    check("JPEG decodes to right size", rects[0][4].size == (ow, oh))

    times = []
    for _ in range(10):
        t = time.perf_counter()
        cap.grab()
        times.append((time.perf_counter() - t) * 1000)
    check("live grab speed", sorted(times)[5] < 60, f"median {sorted(times)[5]:.0f} ms")

    # Deterministic tests with a fake, controllable screen.
    class FakeShot:
        def __init__(self, arr):
            self.height, self.width = arr.shape[:2]
            self.bgra = arr.tobytes()

    class FakeSct:
        monitors = [{"left": 0, "top": 0, "width": 1000, "height": 600}] * 2
        def __init__(self):
            import numpy as np
            self.arr = np.zeros((600, 1000, 4), dtype=np.uint8)
            self.arr[..., 0] = 80
        def grab(self, mon):
            return FakeShot(self.arr)
        def close(self):
            pass

    fcap = Capturer()
    fcap.sct = FakeSct()
    m, info = fcap.grab()
    check("fake: first frame full", info["rects"] == 1 and info["pixels"] == 600_000)
    m, info = fcap.grab()
    check("fake: static screen sends nothing", m is None)
    fcap.sct.arr[300:310, 400:420] = 255         # small change inside tile (r2,c3)
    m, info = fcap.grab()
    _, rects = parse_frame(m)
    check("fake: small change -> one 128px tile", [r[:4] for r in rects] == [(384, 256, 128, 128)],
          str([r[:4] for r in rects]))
    fcap.sct.arr[0:5, 0:1000] = 1                # whole top row of tiles changes
    fcap.sct.arr[590:600, 0:5] = 1               # plus bottom-left corner (edge tile, 600 % 128 != 0)
    m, info = fcap.grab()
    _, rects = parse_frame(m)
    got = sorted(r[:4] for r in rects)
    check("fake: tile runs merged + edge tiles clipped", got == [(0, 0, 1000, 128), (0, 512, 128, 88)], str(got))
    m, _ = fcap.grab()
    check("fake: no refine before idle delay", m is None)
    time.sleep(0.45)
    m, info = fcap.grab()
    check("fake: idle refinement re-sends lossy areas", m is not None and info.get("refine"), str(info))
    m, _ = fcap.grab()
    check("fake: nothing after refinement", m is None)

    # Scaled output
    cap.configure(scale=0.5)
    m, _ = cap.grab()
    _, rects = parse_frame(m)
    _mon, ow2, oh2 = cap.geometry()
    check("50% scale frame size", rects[0][4].size == (ow2, oh2) and abs(ow2 - ow / 2) <= 1, f"{ow2}x{oh2}")
    x, y = cap.to_screen(ow2 / 2, oh2 / 2)
    mon = cap.sct.monitors[cap.monitor_index]
    check("coordinate mapping at 50%", abs(x - (mon["left"] + mon["width"] / 2)) <= 1)
    cap.close()


def wait_user_idle(seconds=2.0, max_wait=60):
    """Input tests move the real mouse; wait until the human stops touching it."""
    import ctypes

    class LASTINPUTINFO(ctypes.Structure):
        _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_uint)]
    li = LASTINPUTINFO(ctypes.sizeof(LASTINPUTINFO), 0)
    end = time.time() + max_wait
    warned = False
    while time.time() < end:
        ctypes.windll.user32.GetLastInputInfo(ctypes.byref(li))
        idle = (ctypes.windll.kernel32.GetTickCount() - li.dwTime) / 1000
        if idle >= seconds:
            return True
        if not warned:
            print("  (waiting for you to stop using mouse/keyboard...)", flush=True)
            warned = True
        time.sleep(0.25)
    return False


# ---------------------------------------------------------- test window
TESTWIN = r'''
import ctypes, json, sys, tkinter as tk
ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
out = sys.argv[1]
ev = []
root = tk.Tk(); root.title("RD-QA-WINDOW"); root.geometry("500x300+200+200"); root.attributes("-topmost", True)
txt = tk.Text(root); txt.pack(fill="both", expand=True)
def key(e): ev.append(["key", e.keysym, e.char])
def click(e): ev.append(["click", e.num, e.x_root, e.y_root])
def wheel(e): ev.append(["wheel", e.delta])
txt.bind("<KeyPress>", key); txt.bind("<ButtonPress>", click, add="+"); txt.bind("<MouseWheel>", wheel)
def dump():
    open(out, "w", encoding="utf-8").write(json.dumps({"events": ev, "text": txt.get("1.0", "end-1c"),
        "geo": [txt.winfo_rootx(), txt.winfo_rooty(), txt.winfo_width(), txt.winfo_height()]}))
    root.after(100, dump)
def grab():
    root.lift(); root.focus_force(); txt.focus_set()
root.after(300, grab); root.after(100, dump)
root.mainloop()
'''


# ---------------------------------------------------------------- live
async def live_tests(password, base="https://127.0.0.1:8765"):
    import aiohttp
    sslctx = ssl.create_default_context()
    sslctx.check_hostname = False
    sslctx.verify_mode = ssl.CERT_NONE
    conn = aiohttp.TCPConnector(ssl=sslctx)
    jar = aiohttp.CookieJar(unsafe=True)  # allow cookies for IP-address hosts

    print("== live: HTTP / auth")
    async with aiohttp.ClientSession(connector=conn, cookie_jar=jar) as http:
        r = await http.get(base + "/", allow_redirects=False)
        check("unauthenticated / redirects to login", r.status == 302 and r.headers["Location"] == "/login")
        check("security headers present", r.headers.get("X-Frame-Options") == "DENY"
              and "frame-ancestors 'none'" in r.headers.get("Content-Security-Policy", ""))
        r = await http.get(base + "/ws", allow_redirects=False)
        check("unauthenticated websocket refused", r.status == 401)
        r = await http.post(base + "/upload", data={"file": b"x"}, allow_redirects=False)
        check("unauthenticated upload refused", r.status == 401)
        r = await http.get(base + "/static/../data/config.json", allow_redirects=False)
        check("config not reachable via static path", r.status in (403, 404))
        r = await http.get(base + "/static/%2e%2e/data/config.json", allow_redirects=False)
        check("config not reachable via encoded traversal", r.status in (400, 403, 404))

        t = time.perf_counter()
        r = await http.post(base + "/login", data={"password": "wrong"}, allow_redirects=False)
        check("wrong password rejected (with delay)", r.status == 302 and "err=1" in r.headers["Location"]
              and time.perf_counter() - t > 1.0)
        check("no cookie on failed login", "rd_session" not in {c.key for c in http.cookie_jar})
        r = await http.post(base + "/login", data={"password": password}, allow_redirects=False)
        check("correct password logs in", r.status == 302 and r.headers["Location"] == "/")
        setc = r.headers.get("Set-Cookie", "")
        check("cookie is HttpOnly, Secure, SameSite=Strict",
              "HttpOnly" in setc and "Secure" in setc and "SameSite=Strict" in setc)
        r = await http.get(base + "/", allow_redirects=False)
        check("authenticated / serves app", r.status == 200 and "screen" in await r.text())

        try:
            async with http.ws_connect(base.replace("https", "wss") + "/ws",
                                       headers={"Origin": "https://evil.example.com"}) as _:
                ok = False
        except aiohttp.WSServerHandshakeError as e:
            ok = e.status == 403
        check("cross-origin websocket rejected", ok)

        print("== live: streaming")
        ws = await http.ws_connect(base.replace("https", "wss") + "/ws",
                                   headers={"Origin": base}, max_msg_size=0)
        init = json.loads((await ws.receive()).data)
        check("init message", init.get("t") == "init" and init["width"] > 0, f"{init['width']}x{init['height']}")
        frames, nbytes = 0, 0
        first = None
        t0 = time.perf_counter()
        pending = []

        async def recv_until(pred, timeout=5):
            end = time.perf_counter() + timeout
            while time.perf_counter() < end:
                try:
                    msg = await asyncio.wait_for(ws.receive(), end - time.perf_counter())
                except asyncio.TimeoutError:
                    break
                if msg.type == aiohttp.WSMsgType.BINARY:
                    nonlocal frames, nbytes, first
                    frames += 1
                    nbytes += len(msg.data)
                    if first is None:
                        first = msg.data
                    await ws.send_json({"t": "ack"})
                elif msg.type == aiohttp.WSMsgType.TEXT:
                    m = json.loads(msg.data)
                    pending.append(m)
                    if pred(m):
                        return m
                else:
                    break
            return None

        await ws.send_json({"t": "ping", "ts": 1})
        pong = await recv_until(lambda m: m["t"] == "pong")
        check("ping/pong", pong is not None)
        if first is None:
            await recv_until(lambda m: False, 1.5)
        _, rects = parse_frame(first)
        check("first frame full-screen and decodable", rects[0][4].size == (init["width"], init["height"]))

        print("== live: mouse/keyboard (opens a test window)")
        out = Path(tempfile.gettempdir()) / "rd_qa_events.json"
        out.unlink(missing_ok=True)
        orig_pos = winput.cursor_pos()
        idle = asyncio.ensure_future(asyncio.to_thread(wait_user_idle))
        while not idle.done():  # keep servicing the websocket (heartbeat) while waiting
            await recv_until(lambda m: False, 0.2)
        proc = subprocess.Popen([sys.executable, "-c", TESTWIN, str(out)])
        try:
            data = None
            for _ in range(200):  # Tk can take a while to start on a busy machine
                await recv_until(lambda m: False, 0.1)
                if out.exists():
                    try:
                        data = json.loads(out.read_text("utf-8"))
                        break
                    except Exception:
                        pass
            await recv_until(lambda m: False, 0.8)  # let the window finish appearing / take focus
            data = json.loads(out.read_text("utf-8"))
            gx, gy, gw, gh = data["geo"]
            mon = init["monitors"][init["monitor"]]
            # viewer coords (scale 1) = screen - monitor origin
            vx, vy = gx + gw // 2 - mon["left"], gy + gh // 2 - mon["top"]
            for _attempt in range(3):  # retry: a human may be moving the real mouse
                await ws.send_json({"t": "mm", "x": vx, "y": vy})
                await recv_until(lambda m: False, 0.05)
                px, py = winput.cursor_pos()
                if (px, py) == (gx + gw // 2, gy + gh // 2):
                    break
            check("mouse move lands on exact pixel", (px, py) == (gx + gw // 2, gy + gh // 2), f"{px},{py}")
            await ws.send_json({"t": "md", "b": 0, "x": vx, "y": vy})
            await ws.send_json({"t": "mu", "b": 0, "x": vx, "y": vy})
            await ws.send_json({"t": "wh", "dy": -120, "dx": 0})
            await recv_until(lambda m: False, 0.5)

            fg = winput.user32.GetForegroundWindow()
            buf = winput.ctypes.create_unicode_buffer(256)
            winput.user32.GetWindowTextW(fg, buf, 256)
            if buf.value != "RD-QA-WINDOW":
                check("test window has focus (needed for key tests)", False, buf.value)
            else:
                for code in ["KeyH", "KeyI", "Space", "Digit1"]:
                    await ws.send_json({"t": "kd", "code": code, "key": "?"})
                    await ws.send_json({"t": "ku", "code": code, "key": "?"})
                await ws.send_json({"t": "kd", "code": "ShiftLeft", "key": "Shift"})
                await ws.send_json({"t": "kd", "code": "KeyQ", "key": "Q"})
                await ws.send_json({"t": "ku", "code": "KeyQ", "key": "Q"})
                await ws.send_json({"t": "ku", "code": "ShiftLeft", "key": "Shift"})
                await ws.send_json({"t": "text", "s": " çãé€😀"})
                await ws.send_json({"t": "kd", "code": "ArrowLeft", "key": "ArrowLeft"})
                await ws.send_json({"t": "ku", "code": "ArrowLeft", "key": "ArrowLeft"})
                await ws.send_json({"t": "kd", "code": "Backspace", "key": "Backspace"})
                await ws.send_json({"t": "ku", "code": "Backspace", "key": "Backspace"})
                # stuck-key protection: press Ctrl, then 'release' must lift it
                await ws.send_json({"t": "kd", "code": "ControlLeft", "key": "Control"})
                await ws.send_json({"t": "release"})
                await recv_until(lambda m: False, 0.8)
                data = json.loads(out.read_text("utf-8"))
                txt = data["text"]
                # typed "hi 1Q çãé€😀", then Left + Backspace deletes the char before the emoji
                check("typed keys + unicode arrive in the window", txt == "hi 1Q çãé😀", repr(txt))
                ctrl = winput.user32.GetAsyncKeyState(0x11) & 0x8000
                check("'release' lifts held modifier keys", not ctrl)
            data = json.loads(out.read_text("utf-8"))
            kinds = [e[0] for e in data["events"]]
            check("click received by window", "click" in kinds)
            check("wheel received by window", "wheel" in kinds)
        finally:
            proc.kill()
            winput.mouse_move(*orig_pos)

        print("== live: clipboard")
        orig_clip = winput.clipboard_get()
        try:
            await ws.send_json({"t": "clipset", "text": "QA clipboard ✓ ç"})
            await recv_until(lambda m: False, 0.3)
            check("clipset reaches host clipboard", winput.clipboard_get() == "QA clipboard ✓ ç")
            winput.clipboard_set("from host 123")
            m = await recv_until(lambda m: m["t"] == "clipchanged", 2)
            check("host clipboard change notified", m is not None)
            await ws.send_json({"t": "clipget"})
            m = await recv_until(lambda m: m["t"] == "clip")
            check("clipget returns host clipboard", m and m["text"] == "from host 123")
        finally:
            if orig_clip is not None:
                winput.clipboard_set(orig_clip)

        print("== live: settings + throughput")
        await ws.send_json({"t": "settings", "scale": 0.5, "quality": 60, "fps": 30})
        m = await recv_until(lambda m: m["t"] == "init")
        check("settings applied", m and abs(m["scale"] - 0.5) < 1e-6 and m["quality"] == 60,
              f"{m['width']}x{m['height']}" if m else "")
        await ws.send_json({"t": "settings", "scale": 1, "quality": 75})
        await recv_until(lambda m: m["t"] == "init")
        frames = nbytes = 0
        # animate something so frames flow: move the mouse in a loop over a window?
        # Instead force refreshes to measure full-frame throughput.
        t0 = time.perf_counter()
        while time.perf_counter() - t0 < 3:
            await ws.send_json({"t": "refresh"})
            await recv_until(lambda m: False, 0.05)
        dt = time.perf_counter() - t0
        check("full-frame refresh throughput", frames / dt >= 8,
              f"{frames / dt:.1f} full frames/s, {nbytes * 8 / dt / 1e6:.1f} Mbps")
        await ws.close()

        print("== live: upload")
        name = f"rd_qa_upload_{int(time.time())}.txt"
        form = aiohttp.FormData()
        form.add_field("file", b"hello from QA", filename="..\\..\\" + name)
        r = await http.post(base + "/upload", data=form, headers={"Origin": base})
        j = await r.json()
        cfg = json.loads((Path(os.environ.get("RD_DATA_DIR") or ROOT / "data") / "config.json").read_text("utf-8"))
        saved = Path(cfg["upload_dir"]) / j["saved"][0]
        check("upload saved with traversal stripped", r.status == 200 and saved.exists()
              and saved.parent == Path(cfg["upload_dir"]) and saved.read_bytes() == b"hello from QA", str(saved))
        saved.unlink(missing_ok=True)
        form = aiohttp.FormData()
        form.add_field("file", b"x", filename="x.txt")
        r = await http.post(base + "/upload", data=form, headers={"Origin": "https://evil.example.com"})
        check("cross-origin upload rejected", r.status == 403)

        print("== live: brute-force lockout (uses a fake IP via a separate limiter check)")
        # the real limiter is per-IP; hammering 127.0.0.1 would lock us out of further tests,
        # so we just verify the lock message path with 5 failures at the very end.
        for i in range(5):
            r = await http.post(base + "/login", data={"password": f"bad{i}"}, allow_redirects=False)
        check("5 failures -> locked out", "locked=" in r.headers["Location"], r.headers["Location"])
        r = await http.post(base + "/login", data={"password": password}, allow_redirects=False)
        check("correct password refused while locked", "locked=" in r.headers["Location"])


def main():
    unit_tests()
    if "--live" in sys.argv:
        pw = sys.argv[sys.argv.index("--live") + 1]
        asyncio.run(live_tests(pw))
    failed = [n for n, ok in results if not ok]
    print(f"\n{len(results) - len(failed)}/{len(results)} passed")
    if failed:
        print("FAILED:", *failed, sep="\n  ")
        sys.exit(1)


if __name__ == "__main__":
    main()
