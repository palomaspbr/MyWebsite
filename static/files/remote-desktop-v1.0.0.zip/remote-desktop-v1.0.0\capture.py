"""Screen capture with tile-based change detection and JPEG encoding.

One Capturer per viewer session; it must only be used from a single thread
(mss handles are thread-bound), so the server runs it in a 1-worker executor.
"""
import io
import struct
import time

import mss
import numpy as np
from PIL import Image

TILE = 128            # change-detection tile size, in captured (full-res) pixels
FULL_FRAME_RATIO = 0.5  # if more than this fraction changed, send one full frame

# Binary frame message:
#   u8 type (1)  u16 rect_count  then per rect: u16 x, u16 y, u16 w, u16 h, u32 len, <jpeg>
HDR = struct.Struct("<BH")
RECT = struct.Struct("<HHHHI")


class Capturer:
    def __init__(self):
        self.sct = None
        self.monitor_index = 1
        self.scale = 1.0
        self.quality = 70
        self.prev = None          # previous raw frame as uint32 (h, w)
        self.lossy = None         # bool tiles sent lossy and not yet refined
        self.idle_since = None
        self.mon = None

    # -- configuration -------------------------------------------------------
    def _ensure(self):
        if self.sct is None:
            self.sct = mss.mss()

    def monitors(self):
        self._ensure()
        mons = self.sct.monitors
        return [{"index": i, "left": m["left"], "top": m["top"],
                 "width": m["width"], "height": m["height"],
                 "name": "All monitors" if i == 0 else f"Monitor {i}"}
                for i, m in enumerate(mons)]

    def configure(self, monitor=None, scale=None, quality=None):
        self._ensure()
        if monitor is not None:
            n = len(self.sct.monitors)
            self.monitor_index = monitor if 0 <= monitor < n else 1
        if scale is not None:
            self.scale = min(max(float(scale), 0.1), 1.0)
        if quality is not None:
            self.quality = min(max(int(quality), 10), 95)
        self.reset()

    def reset(self):
        """Force the next frame to be a full refresh."""
        self.prev = None
        self.lossy = None
        self.idle_since = None

    def geometry(self):
        """(monitor dict, output width, output height)."""
        self._ensure()
        mon = self.sct.monitors[self.monitor_index]
        ow = max(1, int(round(mon["width"] * self.scale)))
        oh = max(1, int(round(mon["height"] * self.scale)))
        return mon, ow, oh

    def to_screen(self, x, y):
        """Map output (viewer) pixel coords to absolute virtual-desktop coords."""
        mon, _, _ = self.geometry()
        return mon["left"] + x / self.scale, mon["top"] + y / self.scale

    # -- capture ---------------------------------------------------------------
    def grab(self):
        """Capture and return (message_bytes or None, info dict).

        Returns None when nothing needs to be sent.
        """
        self._ensure()
        mon, ow, oh = self.geometry()
        shot = self.sct.grab(mon)
        w, h = shot.width, shot.height
        raw = shot.bgra
        cur = np.frombuffer(raw, dtype=np.uint32).reshape(h, w)

        ty = range(0, h, TILE)
        tx = range(0, w, TILE)
        refine = False
        if self.prev is None or self.prev.shape != cur.shape:
            changed = np.ones((len(ty), len(tx)), dtype=bool)
            self.lossy = np.zeros_like(changed)
        else:
            diff = cur != self.prev
            if not diff.any():
                changed = None
            else:
                rows = np.add.reduceat(diff, list(ty), axis=0, dtype=np.int32)
                changed = np.add.reduceat(rows, list(tx), axis=1, dtype=np.int32) > 0
        self.prev = cur.copy()

        quality = self.quality
        if changed is None:
            # Screen static: after a short idle, re-send lossy areas at high quality.
            now = time.monotonic()
            if self.idle_since is None:
                self.idle_since = now
            if self.quality >= 90 or self.lossy is None or not self.lossy.any() \
                    or now - self.idle_since < 0.4:
                return None, {}
            changed = self.lossy.copy()
            quality = 92
            refine = True
        else:
            self.idle_since = None

        if refine:
            self.lossy[:] = False
        else:
            if self.quality < 90:
                self.lossy |= changed
            else:
                self.lossy[changed] = False

        img = Image.frombuffer("RGB", (w, h), raw, "raw", "BGRX", 0, 1)
        if (ow, oh) != (w, h):
            img = img.resize((ow, oh), Image.BILINEAR)
        sx, sy = ow / w, oh / h

        rects = []
        if changed.mean() > FULL_FRAME_RATIO:
            rects.append((0, 0, ow, oh))
        else:
            # Merge horizontal runs of changed tiles, then stack identical runs vertically.
            runs = {}
            order = []
            for r in range(changed.shape[0]):
                c = 0
                row = changed[r]
                while c < len(row):
                    if row[c]:
                        c0 = c
                        while c < len(row) and row[c]:
                            c += 1
                        key = (c0, c)
                        if key in runs and runs[key][1] == r:
                            runs[key] = (runs[key][0], r + 1)
                        else:
                            if key in runs:
                                order.append((key, runs[key]))
                            runs[key] = (r, r + 1)
                    else:
                        c += 1
            order.extend(runs.items())
            for (c0, c1), (r0, r1) in order:
                x0, y0 = c0 * TILE, r0 * TILE
                x1, y1 = min(c1 * TILE, w), min(r1 * TILE, h)
                X0, Y0 = int(x0 * sx), int(y0 * sy)
                X1, Y1 = min(int(round(x1 * sx)), ow), min(int(round(y1 * sy)), oh)
                if X1 > X0 and Y1 > Y0:
                    rects.append((X0, Y0, X1 - X0, Y1 - Y0))

        parts = [HDR.pack(1, len(rects))]
        total_px = 0
        for x, y, rw, rh in rects:
            buf = io.BytesIO()
            region = img if (rw, rh) == (ow, oh) else img.crop((x, y, x + rw, y + rh))
            region.save(buf, "JPEG", quality=quality, optimize=False,
                        subsampling=0 if quality >= 90 else 2)
            data = buf.getvalue()
            parts.append(RECT.pack(x, y, rw, rh, len(data)))
            parts.append(data)
            total_px += rw * rh
        return b"".join(parts), {"rects": len(rects), "pixels": total_px, "refine": refine}

    def close(self):
        if self.sct is not None:
            self.sct.close()
            self.sct = None
