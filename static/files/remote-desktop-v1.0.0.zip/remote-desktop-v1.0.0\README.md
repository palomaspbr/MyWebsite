# Remote Desktop

Control a Windows PC from any other device on your network, in the browser —
like AnyDesk/TeamViewer, but self-hosted, small and readable (≈1,500 lines).

- **Host**: a small Python program on the PC you want to control.
- **Viewer**: any modern browser (Chrome, Edge, Firefox, Safari — desktop, tablet or phone).
  Nothing to install on the viewing side.

> Built for **personal use on your own network** (home LAN, or a VPN such as
> Tailscale). It is not meant to be exposed directly to the internet.

## Features

- Live screen streaming (only changed regions are sent; sharp text when the screen is idle)
- Full mouse (move, all buttons, wheel, drag) and keyboard (any layout — ABNT2, US, …, accents/dead keys)
- Special keys menu (Win, Alt+Tab, Ctrl+Shift+Esc, Win+R…) and fullscreen with keyboard lock
- Multiple monitors, quality / resolution / FPS controls, fit or 1:1 view
- Clipboard: get / set the host clipboard, or "type" text into the host
- Send files to the host (button or drag & drop)
- Mirrors the host's mouse cursor shape
- Touch support: tap = click, long-press = right click, drag, two-finger scroll, on-screen keyboard
- On-screen banner on the host while someone is connected, with a **Disconnect** button

## Security

| Protection | What it does |
|---|---|
| HTTPS (TLS) | Everything — password, keystrokes, screen — is encrypted. A self-signed certificate is created on first run. |
| Strong password | Random 12-character password generated on first run; stored only as a salted PBKDF2 hash. |
| Brute-force lockout | 5 wrong passwords ⇒ that address is locked out for 15 minutes; each failure is delayed. |
| Local-network only | Connections from public internet addresses are refused, even if a router port is forwarded by mistake. Allowed: LAN, localhost, link-local, Tailscale/CGNAT (100.64.0.0/10). |
| Sessions | Signed, expiring HttpOnly + Secure + SameSite=Strict cookies. Changing the password or pressing **Disconnect** on the host revokes all sessions. |
| Web hardening | Strict Content-Security-Policy, anti-clickjacking, WebSocket/upload Origin checks, sanitised upload filenames. |
| Visibility | Red banner on the host screen whenever a viewer is connected; every login, failure and connection is logged in the host window. |

See [docs/SECURITY.md](docs/SECURITY.md) for the threat model and limitations.

## Quick start (on the PC to be controlled)

1. Install **Python 3.10+** from <https://www.python.org/downloads/> — tick **"Add python.exe to PATH"**.
2. Unzip this folder somewhere (e.g. `C:\RemoteDesktop`).
3. Double-click **`start.bat`**. The first run installs dependencies (about a minute) and then shows:

   ```
    open:  https://192.168.x.x:8765
    password: aB3dEf7hJk9m      <- write it down, shown only once
   ```

4. Allow it through Windows Firewall for your **local network** (once):
   right-click **`allow-firewall.bat`** → *Run as administrator*.
   Make sure your network is set to **Private** in Windows settings.

## Connect (from another device)

1. Open the `https://…:8765` address in a browser.
2. The browser warns about the certificate the first time (it is self-signed) —
   choose **Advanced → Continue/Proceed**. You can compare the fingerprint shown
   in the host window with the one in the browser's certificate viewer.
3. Enter the password. Done.

Tips: the toolbar has monitor / quality / resolution / FPS selectors. Use **⛶**
(fullscreen) so shortcuts like Alt+Tab and the Windows key go to the remote PC
(Chrome/Edge). In fullscreen, move the mouse to the top edge to show the toolbar.

## Command line options

```
start.bat                      normal start
start.bat --new-password       generate a new random password (revokes all sessions)
start.bat --password MyPass99  set your own password (min 8 characters)
start.bat --port 9000          use another port (remembered)
start.bat --no-indicator       don't show the on-screen banner
start.bat --http               disable HTTPS (not recommended)
start.bat --allow-public-ips   accept non-local addresses (DANGEROUS; see docs/SECURITY.md)
```

Settings are saved in `data\config.json`. The `data` folder holds your password
hash, session key and TLS key — **never share it**. Delete it to reset everything.
Received files go to `Downloads\RemoteDesktop` (change `upload_dir` in the config).

## Using it away from home

Don't port-forward. Install [Tailscale](https://tailscale.com/) (free) on both
devices and open `https://<host's tailscale IP>:8765` — the traffic stays inside
your private, encrypted Tailscale network and the host already accepts it.

## Start automatically with Windows

Press `Win+R`, type `shell:startup`, and put a shortcut to `start.bat` in that folder.

## Limitations

- Windows hosts only (the viewer works anywhere).
- No audio.
- Ctrl+Alt+Del, the lock/login screen and UAC prompts can't be seen or controlled
  (Windows isolates them; only system services can). Avoid locking the PC remotely.
- To control windows running **as administrator**, the host must also run as administrator.
- Performance: roughly 20–30 fps at 1080p on a LAN; lower *Quality*/*Resolution* on slow Wi-Fi.

## Development

```
tests\qa_test.py      unit + live tests (security, capture, input, clipboard, upload)
tests\browser_test.py end-to-end test of the web viewer in headless Chrome/Edge (needs: pip install playwright)
tools\run_qa.ps1      runs everything against a throw-away host
tools\package.ps1     builds the distributable zip (with a privacy check)
```

Live tests briefly move the mouse, type into a test window they open, and
temporarily use the clipboard (restored afterwards).

Architecture notes: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## License

MIT — see [LICENSE](LICENSE).
