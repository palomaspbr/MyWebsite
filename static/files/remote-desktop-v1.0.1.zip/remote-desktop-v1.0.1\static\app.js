'use strict';
(() => {
  const $ = (id) => document.getElementById(id);
  const canvas = $('screen');
  const ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });
  const stage = $('stage');
  const overlay = $('overlay');

  let ws = null;
  let connected = false;
  let retryMs = 500;
  let fit = true;
  let remoteW = 0, remoteH = 0;
  let frameChain = Promise.resolve();
  const settings = loadSettings();

  // ------------------------------------------------------------ stats
  let bytes = 0, frames = 0, rtt = 0;
  setInterval(() => {
    if (!connected) { $('stats').textContent = ''; return; }
    $('stats').textContent = `${frames} fps · ${(bytes * 8 / 1e6).toFixed(1)} Mbps · ${rtt} ms`;
    bytes = 0; frames = 0;
  }, 1000);
  setInterval(() => send({ t: 'ping', ts: performance.now() }), 2000);

  function loadSettings() {
    try { return JSON.parse(localStorage.getItem('rd_settings') || '{}'); } catch { return {}; }
  }
  function saveSettings() {
    try { localStorage.setItem('rd_settings', JSON.stringify(settings)); } catch { }
  }

  function toast(msg, ms = 2500) {
    const t = $('toast');
    t.textContent = msg; t.hidden = false;
    clearTimeout(toast._t);
    toast._t = setTimeout(() => (t.hidden = true), ms);
  }

  function setStatus(state, text) {
    $('status').className = 'dot ' + state;
    if (text) overlay.textContent = text;
    overlay.hidden = state === 'ok';
  }

  // ------------------------------------------------------------ connection
  function connect() {
    setStatus('wait', 'Connecting…');
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    ws = new WebSocket(`${proto}//${location.host}/ws`);
    ws.binaryType = 'arraybuffer';
    ws.onopen = () => {
      connected = true; retryMs = 500;
      setStatus('ok');
      // apply saved preferences
      const s = {};
      for (const k of ['quality', 'scale', 'fps', 'monitor']) if (settings[k] != null) s[k] = settings[k];
      if (Object.keys(s).length) send({ t: 'settings', ...s });
      canvas.focus();
    };
    ws.onclose = (ev) => {
      connected = false;
      if (ev.code === 4001) {
        setStatus('off', 'Disconnected by the host.');
        setTimeout(() => (location.href = '/login'), 2500);
        return;
      }
      // session may have expired / been revoked – check, go to login if so
      fetch('/', { redirect: 'manual', cache: 'no-store' }).then((r) => {
        if (r.type === 'opaqueredirect' || r.status === 302) location.href = '/login';
      }).catch(() => { });
      setStatus('off', 'Disconnected – reconnecting…');
      setTimeout(connect, retryMs);
      retryMs = Math.min(retryMs * 2, 5000);
    };
    ws.onmessage = (ev) => {
      if (typeof ev.data === 'string') onControl(JSON.parse(ev.data));
      else onFrame(ev.data);
    };
  }

  function send(obj) {
    if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj));
  }

  function onControl(m) {
    switch (m.t) {
      case 'init': {
        $('hostname').textContent = m.host;
        document.title = `${m.host} – Remote Desktop`;
        const sel = $('monitor');
        sel.innerHTML = '';
        for (const mon of m.monitors) {
          const o = document.createElement('option');
          o.value = mon.index;
          o.textContent = window.innerWidth < 760 ? (mon.index ? `Mon ${mon.index}` : "All") : `${mon.name} (${mon.width}×${mon.height})`;
          sel.appendChild(o);
        }
        sel.value = m.monitor;
        selectNearest($('quality'), m.quality);
        selectNearest($('scale'), m.scale);
        selectNearest($('fps'), m.fps);
        if (m.width !== remoteW || m.height !== remoteH) {
          remoteW = canvas.width = m.width;
          remoteH = canvas.height = m.height;
          ctx.fillStyle = '#000'; ctx.fillRect(0, 0, remoteW, remoteH);
        }
        layout();
        break;
      }
      case 'cursor':
        canvas.style.cursor = m.c;
        break;
      case 'pong':
        rtt = Math.round(performance.now() - m.ts);
        break;
      case 'clip':
        $('clipText').value = m.text;
        toast('Host clipboard received');
        break;
      case 'clipchanged':
        $('clipDot').hidden = false;
        break;
    }
  }

  function selectNearest(sel, value) {
    let best = null, bestD = Infinity;
    for (const o of sel.options) {
      const d = Math.abs(parseFloat(o.value) - value);
      if (d < bestD) { bestD = d; best = o; }
    }
    if (best) sel.value = best.value;
  }

  // ------------------------------------------------------------ frames
  function onFrame(buf) {
    bytes += buf.byteLength;
    const dv = new DataView(buf);
    if (dv.getUint8(0) !== 1) return;
    const n = dv.getUint16(1, true);
    const rects = [];
    let off = 3;
    for (let i = 0; i < n; i++) {
      const x = dv.getUint16(off, true), y = dv.getUint16(off + 2, true);
      const w = dv.getUint16(off + 4, true), h = dv.getUint16(off + 6, true);
      const len = dv.getUint32(off + 8, true);
      off += 12;
      const blob = new Blob([new Uint8Array(buf, off, len)], { type: 'image/jpeg' });
      off += len;
      rects.push({ x, y, w, h, img: decode(blob) });
    }
    // Decode in parallel, draw strictly in arrival order, then ack.
    frameChain = frameChain.then(async () => {
      try {
        const imgs = await Promise.all(rects.map((r) => r.img));
        rects.forEach((r, i) => {
          ctx.drawImage(imgs[i], r.x, r.y, r.w, r.h);
          if (imgs[i].close) imgs[i].close();
        });
        frames++;
      } catch (e) { console.warn('frame decode failed', e); }
      send({ t: 'ack' });
    });
  }

  function decode(blob) {
    if (window.createImageBitmap) return createImageBitmap(blob);
    return new Promise((res, rej) => {
      const img = new Image();
      img.onload = () => { URL.revokeObjectURL(img.src); res(img); };
      img.onerror = rej;
      img.src = URL.createObjectURL(blob);
    });
  }

  // ------------------------------------------------------------ layout
  function layout() {
    if (!remoteW) return;
    stage.classList.toggle('fit', fit);
    stage.classList.toggle('actual', !fit);
    $('btnFit').textContent = fit ? 'Fit' : '1:1';
    if (fit) {
      const sw = stage.clientWidth, sh = stage.clientHeight;
      const k = Math.min(sw / remoteW, sh / remoteH);
      canvas.style.width = Math.floor(remoteW * k) + 'px';
      canvas.style.height = Math.floor(remoteH * k) + 'px';
    } else {
      // 1:1 with the *host* resolution: undo the network downscale
      const scale = parseFloat($('scale').value) || 1;
      const dpr = window.devicePixelRatio || 1;
      canvas.style.width = Math.round(remoteW / scale / dpr) + 'px';
      canvas.style.height = Math.round(remoteH / scale / dpr) + 'px';
    }
  }
  window.addEventListener('resize', layout);

  // ------------------------------------------------------------ mouse
  function pos(e) {
    const r = canvas.getBoundingClientRect();
    const x = Math.round((e.clientX - r.left) * remoteW / r.width);
    const y = Math.round((e.clientY - r.top) * remoteH / r.height);
    return { x: Math.max(0, Math.min(remoteW - 1, x)), y: Math.max(0, Math.min(remoteH - 1, y)) };
  }

  let lastMove = null;
  let movePending = false;
  function queueMove(p) {
    lastMove = p;
    if (movePending) return;
    movePending = true;
    // coalesce to at most one move per ~4ms to avoid flooding while staying precise
    setTimeout(() => { movePending = false; if (lastMove) send({ t: 'mm', ...lastMove }); lastMove = null; }, 4);
  }
  function flushMove() { if (lastMove) { send({ t: 'mm', ...lastMove }); lastMove = null; } }

  canvas.addEventListener('pointermove', (e) => {
    if (e.pointerType === 'touch') return;
    queueMove(pos(e));
  });
  canvas.addEventListener('pointerdown', (e) => {
    if (e.pointerType === 'touch') return;
    e.preventDefault();
    canvas.focus();
    canvas.setPointerCapture(e.pointerId);
    flushMove();
    send({ t: 'md', b: e.button, ...pos(e) });
  });
  canvas.addEventListener('pointerup', (e) => {
    if (e.pointerType === 'touch') return;
    e.preventDefault();
    flushMove();
    send({ t: 'mu', b: e.button, ...pos(e) });
  });
  canvas.addEventListener('contextmenu', (e) => e.preventDefault());
  canvas.addEventListener('auxclick', (e) => e.preventDefault());
  // stop browser back/forward on mouse side buttons
  window.addEventListener('mouseup', (e) => { if (e.button === 3 || e.button === 4) e.preventDefault(); });

  let wheelAccY = 0, wheelAccX = 0;
  canvas.addEventListener('wheel', (e) => {
    e.preventDefault();
    const k = e.deltaMode === 1 ? 40 : e.deltaMode === 2 ? 800 : 1.2;
    wheelAccY += -e.deltaY * k;
    wheelAccX += e.deltaX * k;
    const dy = Math.trunc(wheelAccY), dx = Math.trunc(wheelAccX);
    if (dy || dx) {
      wheelAccY -= dy; wheelAccX -= dx;
      send({ t: 'wh', dy, dx });
    }
  }, { passive: false });

  // ------------------------------------------------------------ touch
  // 1 finger: tap = click, drag = left-drag, long-press = right click
  // 2 fingers: scroll
  let touch = null;
  canvas.addEventListener('touchstart', (e) => {
    e.preventDefault();
    if (e.touches.length === 1) {
      const t = e.touches[0];
      const p = pos(t);
      touch = { start: p, last: p, sx: t.clientX, sy: t.clientY, down: false, moved: false, two: false };
      send({ t: 'mm', ...p });
      touch.timer = setTimeout(() => {
        if (touch && !touch.moved && !touch.two) {
          send({ t: 'md', b: 2, ...p }); send({ t: 'mu', b: 2, ...p });
          touch.done = true;
          if (navigator.vibrate) navigator.vibrate(30);
        }
      }, 550);
    } else if (e.touches.length === 2 && touch) {
      clearTimeout(touch.timer);
      if (touch.down) { send({ t: 'mu', b: 0, ...touch.last }); touch.down = false; }
      touch.two = true;
      touch.sy = (e.touches[0].clientY + e.touches[1].clientY) / 2;
      touch.sx = (e.touches[0].clientX + e.touches[1].clientX) / 2;
    }
  }, { passive: false });
  canvas.addEventListener('touchmove', (e) => {
    e.preventDefault();
    if (!touch || touch.done) return;
    if (touch.two && e.touches.length >= 2) {
      const cy = (e.touches[0].clientY + e.touches[1].clientY) / 2;
      const cx = (e.touches[0].clientX + e.touches[1].clientX) / 2;
      const dy = Math.round((cy - touch.sy) * 3), dx = Math.round((touch.sx - cx) * 3);
      if (Math.abs(dy) >= 10 || Math.abs(dx) >= 10) {
        send({ t: 'wh', dy, dx }); touch.sy = cy; touch.sx = cx;
      }
      return;
    }
    const t = e.touches[0];
    if (!touch.moved && Math.hypot(t.clientX - touch.sx, t.clientY - touch.sy) > 8) {
      touch.moved = true;
      clearTimeout(touch.timer);
      send({ t: 'md', b: 0, ...touch.start });
      touch.down = true;
    }
    if (touch.moved) { touch.last = pos(t); queueMove(touch.last); }
  }, { passive: false });
  canvas.addEventListener('touchend', (e) => {
    e.preventDefault();
    if (!touch) return;
    if (e.touches.length > 0) return;
    clearTimeout(touch.timer);
    if (touch.down) { flushMove(); send({ t: 'mu', b: 0, ...touch.last }); }
    else if (!touch.moved && !touch.two && !touch.done) {
      send({ t: 'md', b: 0, ...touch.start }); send({ t: 'mu', b: 0, ...touch.start });
    }
    touch = null;
  }, { passive: false });

  // ------------------------------------------------------------ keyboard
  function viewerHasFocus() {
    const a = document.activeElement;
    return !a || a === document.body || a === canvas;
  }
  window.addEventListener('keydown', (e) => {
    if (!viewerHasFocus() || !connected) return;
    e.preventDefault();
    send({ t: 'kd', code: e.code, key: e.key });
  }, true);
  window.addEventListener('keyup', (e) => {
    if (!viewerHasFocus() || !connected) return;
    e.preventDefault();
    send({ t: 'ku', code: e.code, key: e.key });
  }, true);
  window.addEventListener('blur', () => send({ t: 'release' }));
  document.addEventListener('visibilitychange', () => { if (document.hidden) send({ t: 'release' }); });

  // mobile on-screen keyboard
  // Android keyboards (Gboard, SwiftKey…) type through IME "composition": each key press re-sends the
  // whole word being composed ("h", "he", "hel"…), suggestions/autocorrect replace text, and those
  // events can't be cancelled. So we don't read the events: we let the hidden textarea change and
  // send the DIFFERENCE between its old and new contents (removed characters → Backspace, added
  // text → typed). It starts with filler spaces so Backspace also works before anything was typed
  // (it then deletes text on the host); the filler is topped up whenever it runs low.
  const kbd = $('kbdInput');
  const FILL = ' '.repeat(40);
  let kbdLast = FILL;
  let composing = false;
  function kbdReset() {
    kbd.value = FILL;
    kbd.setSelectionRange(FILL.length, FILL.length);
    kbdLast = FILL;
  }
  function kbdSync() {
    const v = kbd.value;
    let i = 0;
    while (i < kbdLast.length && i < v.length && kbdLast[i] === v[i]) i++;
    const del = kbdLast.length - i, ins = v.slice(i);
    kbdLast = v;
    for (let k = 0; k < del; k++) send({ t: 'combo', codes: ['Backspace'] });
    if (ins) send({ t: 'text', s: ins }); // the host types newlines as Enter
    if (composing) return;
    // keep typing at the end, and keep enough filler without letting the box grow forever
    if (kbd.selectionStart !== v.length || kbd.selectionEnd !== v.length) kbd.setSelectionRange(v.length, v.length);
    if (v.length < FILL.length / 2 || v.length > FILL.length + 300) kbdReset();
  }
  $('btnKbd').onclick = () => { kbdReset(); kbd.focus(); };
  kbd.addEventListener('focus', () => { if (!composing && kbd.value !== kbdLast) kbdReset(); });
  kbd.addEventListener('compositionstart', () => { composing = true; });
  kbd.addEventListener('compositionend', () => { composing = false; setTimeout(kbdSync, 0); });
  kbd.addEventListener('input', kbdSync);
  // Keys that don't change the text (hardware keyboards); Backspace/Enter go through kbdSync.
  kbd.addEventListener('keydown', (e) => {
    if (e.isComposing || e.keyCode === 229) return;
    const special = ['Tab', 'Escape', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Delete', 'Home', 'End'];
    if (special.includes(e.key)) { e.preventDefault(); send({ t: 'combo', codes: [e.key] }); }
  });

  // ------------------------------------------------------------ toolbar
  function settingChanged(key, parse) {
    return (e) => {
      const v = parse(e.target.value);
      settings[key] = v; saveSettings();
      send({ t: 'settings', [key]: v });
      canvas.focus();
    };
  }
  $('monitor').onchange = settingChanged('monitor', (v) => parseInt(v, 10));
  $('quality').onchange = settingChanged('quality', (v) => parseInt(v, 10));
  $('scale').onchange = settingChanged('scale', parseFloat);
  $('fps').onchange = settingChanged('fps', (v) => parseInt(v, 10));

  $('btnFit').onclick = () => { fit = !fit; layout(); canvas.focus(); };

  const keysMenu = $('keysMenu');
  $('btnKeys').onclick = (e) => {
    e.stopPropagation();
    const r = $('btnKeys').getBoundingClientRect();
    keysMenu.style.left = Math.min(r.left, window.innerWidth - 250) + 'px';
    keysMenu.style.top = r.bottom + 'px';
    keysMenu.classList.toggle('open');
  };
  document.addEventListener('click', () => keysMenu.classList.remove('open'));
  keysMenu.querySelectorAll('button').forEach((b) => {
    b.onclick = () => {
      send({ t: 'combo', codes: b.dataset.combo.split(',') });
      keysMenu.classList.remove('open');
      canvas.focus();
    };
  });

  // clipboard
  $('btnClip').onclick = () => {
    $('clipPanel').hidden = !$('clipPanel').hidden;
    $('clipDot').hidden = true;
    if (!$('clipPanel').hidden) send({ t: 'clipget' });
  };
  document.querySelectorAll('[data-close]').forEach((b) => {
    b.onclick = () => { $(b.dataset.close).hidden = true; canvas.focus(); };
  });
  $('clipGet').onclick = () => { send({ t: 'clipget' }); $('clipDot').hidden = true; };
  $('clipSet').onclick = () => { send({ t: 'clipset', text: $('clipText').value }); toast('Host clipboard set'); };
  $('clipType').onclick = () => {
    const text = $('clipText').value;
    $('clipPanel').hidden = true;
    canvas.focus();
    setTimeout(() => send({ t: 'text', s: text }), 150);
  };
  $('clipCopy').onclick = async () => {
    const ta = $('clipText');
    try { await navigator.clipboard.writeText(ta.value); }
    catch { ta.select(); document.execCommand('copy'); }
    toast('Copied to this device');
  };

  // fullscreen (+ keyboard lock so Alt+Tab / Win / Esc go to the host on Chrome/Edge)
  $('btnFull').onclick = async () => {
    if (document.fullscreenElement) { await document.exitFullscreen(); return; }
    try {
      await document.documentElement.requestFullscreen();
      if (navigator.keyboard && navigator.keyboard.lock) await navigator.keyboard.lock();
    } catch (e) { toast('Fullscreen not available'); }
    canvas.focus();
  };
  document.addEventListener('fullscreenchange', () => {
    document.body.classList.toggle('fs', !!document.fullscreenElement);
    $('btnFull').classList.toggle('on', !!document.fullscreenElement);
    setTimeout(layout, 50);
  });
  $('hotzone').addEventListener('mouseenter', () => document.body.classList.add('showbar'));
  $('bar').addEventListener('mouseleave', () => document.body.classList.remove('showbar'));

  // ------------------------------------------------------------ file upload
  $('btnUpload').onclick = () => $('fileInput').click();
  $('fileInput').onchange = (e) => { uploadFiles(e.target.files); e.target.value = ''; };
  let dragDepth = 0;
  window.addEventListener('dragenter', (e) => { if (e.dataTransfer.types.includes('Files')) { dragDepth++; $('dropHint').hidden = false; } });
  window.addEventListener('dragleave', () => { if (--dragDepth <= 0) { dragDepth = 0; $('dropHint').hidden = true; } });
  window.addEventListener('dragover', (e) => e.preventDefault());
  window.addEventListener('drop', (e) => {
    e.preventDefault(); dragDepth = 0; $('dropHint').hidden = true;
    if (e.dataTransfer.files.length) uploadFiles(e.dataTransfer.files);
  });

  function uploadFiles(files) {
    if (!files || !files.length) return;
    const fd = new FormData();
    let total = 0;
    for (const f of files) { fd.append('file', f, f.name); total += f.size; }
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/upload');
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) toast(`Uploading… ${Math.round(e.loaded * 100 / e.total)}%`, 60000);
    };
    xhr.onload = () => {
      if (xhr.status === 200) {
        const r = JSON.parse(xhr.responseText);
        toast(`Saved on host: ${r.saved.map((p) => p.split(/[\\/]/).pop()).join(', ')}`, 4000);
      } else toast('Upload failed: ' + xhr.status);
    };
    xhr.onerror = () => toast('Upload failed');
    xhr.send(fd);
    toast(`Uploading ${files.length} file(s), ${(total / 1e6).toFixed(1)} MB…`, 60000);
  }

  connect();
})();
