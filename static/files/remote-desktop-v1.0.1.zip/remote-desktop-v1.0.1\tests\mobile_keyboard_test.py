"""Mobile on-screen keyboard test: simulates Android keyboards (Gboard-style IME composition)
typing into the viewer's hidden textarea and checks what the host would type.

    python tests/mobile_keyboard_test.py

No host needed and nothing is typed on the real desktop: it serves static/ with a throw-away
HTTP server, fakes the WebSocket, and rebuilds the host's text from the `text`/`combo` messages.

Regression for: one tap on an Android keyboard typed several characters on the host, because
each composition event re-sends the whole word being composed ("h", "he", "hel"...).
"""
import functools
import http.server
import json
import sys
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    print("SKIP: playwright not installed (pip install playwright && python -m playwright install chromium)")
    sys.exit(0)

# What Chrome on Android fires for each kind of key press. Composition events can't be cancelled.
SIM = r"""
async (script) => {
  const kbd = document.getElementById('kbdInput');
  document.getElementById('btnKbd').click();
  const tick = () => new Promise(r => setTimeout(r, 5));
  const fire = (type, init) => kbd.dispatchEvent(type.startsWith('composition') ? new CompositionEvent(type, init) : new InputEvent(type, init));
  const setVal = (v) => { kbd.value = v; kbd.setSelectionRange(v.length, v.length); };
  let base = kbd.value, comp = null;
  for (const step of script) {
    if (step[0] === 'word') {            // a word typed letter by letter inside a composition
      fire('compositionstart', { data: '' }); comp = '';
      for (const ch of step[1]) {
        comp += ch;
        fire('beforeinput', { inputType: 'insertCompositionText', data: comp, cancelable: false, bubbles: true });
        setVal(base + comp);
        fire('input', { inputType: 'insertCompositionText', data: comp, bubbles: true });
        await tick();
      }
    } else if (step[0] === 'compose') {  // the keyboard rewrites the composing word (suggestion, autocorrect, backspace)
      comp = step[1];
      fire('beforeinput', { inputType: 'insertCompositionText', data: comp, cancelable: false, bubbles: true });
      setVal(base + comp);
      fire('input', { inputType: 'insertCompositionText', data: comp, bubbles: true });
    } else if (step[0] === 'commit') {   // composition ends (space / punctuation pressed)
      fire('compositionend', { data: comp }); base = kbd.value; comp = null;
    } else if (step[0] === 'text') {     // a plain committed character, e.g. a space
      if (fire('beforeinput', { inputType: 'insertText', data: step[1], cancelable: true, bubbles: true })) {
        setVal(kbd.value + step[1]); fire('input', { inputType: 'insertText', data: step[1], bubbles: true });
      }
      base = kbd.value;
    } else if (step[0] === 'backspace') { // keyboard backspace outside a composition: keyCode 229, then a delete
      kbd.dispatchEvent(new KeyboardEvent('keydown', { key: 'Unidentified', keyCode: 229, bubbles: true, cancelable: true }));
      if (fire('beforeinput', { inputType: 'deleteContentBackward', cancelable: true, bubbles: true }) && kbd.value.length) {
        setVal(kbd.value.slice(0, -1)); fire('input', { inputType: 'deleteContentBackward', bubbles: true });
      }
      base = kbd.value;
    } else if (step[0] === 'enter') {
      if (kbd.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true, cancelable: true }))
          && fire('beforeinput', { inputType: 'insertLineBreak', cancelable: true, bubbles: true })) {
        setVal(kbd.value + '\n'); fire('input', { inputType: 'insertLineBreak', bubbles: true });
      }
      base = kbd.value;
    } else if (step[0] === 'arrow') {    // hardware keyboard key that doesn't change the text
      kbd.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft', code: 'ArrowLeft', keyCode: 37, bubbles: true, cancelable: true }));
    }
    await tick();
  }
}
"""

# (name, steps, text already on the host, expected host text afterwards)
CASES = [
    ("one tap = one character", [["word", "hello"], ["commit"], ["text", " "]], "", "hello "),
    ("autocorrect teh -> the", [["word", "teh"], ["compose", "the"], ["commit"], ["text", " "]], "", "the "),
    ("backspace inside a composing word", [["word", "helo"], ["compose", "hel"], ["compose", "hell"], ["compose", "hello"], ["commit"]], "", "hello"),
    ("backspace after a word", [["word", "abc"], ["commit"], ["text", " "], ["backspace"], ["backspace"]], "", "ab"),
    ("enter", [["word", "hi"], ["commit"], ["enter"], ["word", "yo"], ["commit"]], "", "hi\nyo"),
    ("backspace before typing deletes host text", [["backspace"], ["backspace"]], "XYZ", "X"),
    ("backspace far past the filler", [["backspace"]] * 60, "H" * 70, "H" * 10),
    ("long text (filler is topped up)", sum([[["word", "abcde"], ["commit"], ["text", " "]] for _ in range(80)], []), "", "abcde " * 80),
    ("hardware arrow key", [["word", "ok"], ["commit"], ["arrow"]], "", "ok<ArrowLeft>"),
]


def host_text(msgs, start):
    out = list(start)
    for m in msgs:
        if m.get("t") == "text":
            out.extend(m["s"])
        elif m.get("t") == "combo":
            for c in m["codes"]:
                if c == "Backspace":
                    if out:
                        out.pop()
                elif c == "Enter":
                    out.append("\n")
                else:
                    out.append(f"<{c}>")
    return "".join(out)


def main():
    class Quiet(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *args):
            pass

    handler = functools.partial(Quiet, directory=str(ROOT))
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    url = f"http://127.0.0.1:{httpd.server_address[1]}/static/index.html"
    failed = 0
    try:
        with sync_playwright() as pw:
            try:
                browser = pw.chromium.launch(channel="chrome")
            except Exception:
                browser = pw.chromium.launch()
            for name, steps, start, want in CASES:
                ctx = browser.new_context(viewport={"width": 390, "height": 800}, is_mobile=True, has_touch=True)
                page = ctx.new_page()
                sent, errors = [], []
                page.route_web_socket("**/ws", lambda ws: ws.on_message(lambda m: sent.append(json.loads(m)) if isinstance(m, str) else None))
                page.on("pageerror", lambda e: errors.append(str(e)))
                page.goto(url)
                page.wait_for_timeout(300)
                page.evaluate(SIM, steps)
                page.wait_for_timeout(100)
                got = host_text([m for m in sent if m.get("t") in ("text", "combo")], start)
                ok = got == want and not errors
                failed += not ok
                print(f"{'PASS' if ok else 'FAIL'} {name}" + ("" if ok else f": host got {got!r}, want {want!r} {errors}"))
                ctx.close()
            browser.close()
    finally:
        httpd.shutdown()
    print(f"\n{len(CASES) - failed}/{len(CASES)} passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
