@echo off
rem Opens the host port in Windows Firewall for the LOCAL NETWORK ONLY
rem (Private profile, local subnet). Run once, as Administrator.
rem Usage: allow-firewall.bat [port]    (default 8765)
set PORT=%1
if "%PORT%"=="" set PORT=8765
net session >nul 2>&1
if errorlevel 1 (
  echo Please right-click this file and choose "Run as administrator".
  if not "%2"=="nopause" pause
  exit /b 1
)
netsh advfirewall firewall delete rule name="Remote Desktop host (LAN)" >nul 2>&1
netsh advfirewall firewall delete rule name="Remote Desktop host (VPN)" >nul 2>&1
netsh advfirewall firewall add rule name="Remote Desktop host (LAN)" dir=in action=allow protocol=TCP localport=%PORT% profile=private remoteip=localsubnet
rem Tailscale/CGNAT VPN range (Tailscale marks its adapter as a Private network)
netsh advfirewall firewall add rule name="Remote Desktop host (VPN)" dir=in action=allow protocol=TCP localport=%PORT% profile=private,public remoteip=100.64.0.0/10
echo.
echo Done: TCP port %PORT% allowed from your local subnet (Private networks)
echo and from VPN addresses 100.64.0.0/10 (e.g. Tailscale).
echo Make sure your Wi-Fi/Ethernet network is set to "Private" in Windows settings.
if not "%2"=="nopause" pause
